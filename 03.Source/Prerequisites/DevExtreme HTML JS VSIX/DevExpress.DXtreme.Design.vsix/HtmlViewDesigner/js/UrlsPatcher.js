﻿(function(DX) {
    DX.designer.createUrlsPatcher = function() {
        var patchLinks = function ($links, isContent, callback) {
            $.each(["src", "href"], function(index, attrName) {
                $links.filter("[" + attrName + "]").each(function (index, item) {
                    var $item = $(item),
                        url = patchUrl($item.attr(attrName), isContent);
                    if(url) {
                        callback($item, attrName, url);
                    }
                });
            });
        };
        var isNonFrameworkScriptUrl = function(url) {
            if (url.indexOf(".js") === -1) {
                return false;
            }
            return url.indexOf("dxtreme.") === -1 &&
                url.indexOf("globalize.js") === -1 &&
                url.indexOf("jquery") === -1 &&
                url.indexOf("knockout") === -1 &&
                url.indexOf("js/") === -1 &&
                url.indexOf("layouts/") === -1 &&
                url.toLowerCase().indexOf("layout") === -1;
        };
        var patchUrl = function(url, isContent) {

            var command;
            if (!isContent) {
                if (isNonFrameworkScriptUrl(url) || url.indexOf("://") !== -1) {
                    if (url.indexOf("://") !== -1) {
                        return url;
                    }
                    else {
                        return;
                    }
                }
                command = { command: "patchHeaderUrl", data: url };
            } else {
                command = { command: "patchContentUrl", data: url };
            }
            return externalProcessCommand(command);
        };

        var patchUrls = function($view) {
            patchLinks($view.find("[src],[href]"), true, function($item, attrName, url) {
                $item.attr(attrName, url);
            });
        };

        var addLinksToHeader = function(appHeadContent) {
            var links = $(appHeadContent).filter("[href]"),
                scripts = $(appHeadContent).filter("[src]");
            patchLinks(links, false, function($link, attrName, url) {
                $link.attr(attrName, url);
                findInFrame("head").append($link[0].outerHTML);
            });
            patchLinks(scripts, false, function($script, attrName, url) {
                var script = DevExpress.designer.frameWindow.document.createElement('script');
                script.type = 'text/javascript';
                try {
                    script.text = loadFile(url);
                } catch (e) {
                    $(script).attr("src", url);
                }
                findInFrame("head")[0].appendChild(script);
                
                //T257634 https://code.google.com/p/gmaps-api-issues/issues/detail?id=1403
                try {
                    script.id;                
                } catch (e) {
                        throw {
                            internal: true,
                            message: e.message + " " + url
                        }
                }
            });
        };

        return {
            patchUrl: patchUrl,
            patchUrls: patchUrls,
            addLinksToHeader: addLinksToHeader,
            _patchLinks: patchLinks
        };
    };

    DX.designer.getAppConfig = function(appHeadContent) {
        var scripts = $(appHeadContent).filter("[src]");
        var config = {};
        scripts.each(function() {
            var configFileName = $(this).attr("src");
            if(configFileName.toLowerCase().indexOf(".config.js") > 0) {
                var content = loadFile(configFileName);
                $.extend(true, config, DX.designer.getAppConfigObject(content, configFileName));
            }
        });
        return config.config;
    };

    var regExpExtendAppFromConfigObject = /window\.[a-zA-Z\$_][\w\$]*\s*=\s*\$.extend\s*\(\s*true\s*,\s*window\.[a-zA-Z\$_][\w\$]*\s*,\s*(\{\s*"config"\s*:[\s\S]*\})\s*\)/gm;
    DX.designer.getAppConfigString = function(configFileText, configFileName) {
        regExpExtendAppFromConfigObject.lastIndex = 0;
        var resultArray = regExpExtendAppFromConfigObject.exec(configFileText);
        if(!resultArray || resultArray.length != 2) {
            throw new Error("The '" + configFileName + "' file has incorrect format");
        }
        return resultArray[1];
    }
    DX.designer.getAppConfigObject = function(configFileText, configFileName) {
        var configString = DX.designer.getAppConfigString(configFileText, configFileName),
            bindingParser = new DevExpress.designer.BindingParser(DevExpress.designer.metadata.getTypesOfWidgets());
        return DevExpress.designer.frameWindow.eval("(function() { return {" + bindingParser._patch(configString, {}).bindings + "} })()");
    }

})(DevExpress);