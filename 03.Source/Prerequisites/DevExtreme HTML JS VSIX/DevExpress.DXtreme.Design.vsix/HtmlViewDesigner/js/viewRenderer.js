﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer.viewRenderer = viewRenderer;

    function viewRenderer(viewEngineAdapter, urlsPatcher, bindingParser) {
        this._urlsPatcher = urlsPatcher;
        this._bindingParser = bindingParser;
        this._viewEngineAdapter = viewEngineAdapter;
    }
    $.extend(viewRenderer.prototype, {
        refreshVisualView: function($sourceTree, $surface) {
            if(DX.designer.utils.isBrowserLessThanIE9() && ["ios", "android", "win"].indexOf(this._viewEngineAdapter.viewEngine.device.platform) !== -1) {
                throw Error("Android, iOS and Win8 themes are not supported by your version of Internet Explorer. You should upgrade to Internet Explorer version 9 or higher.");
            }
            this._viewEngineAdapter.clearSurface($surface);
            var $renderedView = this._viewEngineAdapter.getRenderedMarkup(this._createVisualView($sourceTree), {}, $surface);
            this._viewEngineAdapter.appendViewToSurface($surface, $renderedView);
            $renderedView.show();
        },
        setViewEngineAdapter: function(viewEngineAdapter) {
            this._viewEngineAdapter = viewEngineAdapter;
        },
        _getSourceIndex: function($sourceTree) {
            var index = 0;
            for(var i = $sourceTree.children().length - 1; i >= 0; i--) {
                if($sourceTree.children().eq(i).find("*").length > 0) {
                    index = i;
                }
            };
            return index;
        },
        _createVisualView: function($sourceTree) {
            var jQuery = window.dxApplication ? dxApplication.$ : $,
                sourceIndex = this._getSourceIndex($sourceTree),
                $view = jQuery($sourceTree.children().eq(sourceIndex).clone()),
                urlsPatcher = this._urlsPatcher;

            this._linkTreeNodes($sourceTree.children().eq(sourceIndex), $view);
            this._urlsPatcher.patchUrls($view);
            this._bindingParser.patch($view, {}, function(key, value) {
                if(['icon', 'iconSrc', 'imageSrc'].indexOf(key) > -1) {
                    var newValue = urlsPatcher.patchUrl((value || '').replace(/[\'\"\s]/g, ''), true);
                    if(newValue) {
                        return '"' + newValue.replace(/\\/g, '\\\\') + '"';
                    }
                }
                return value;
            });
            return $view;
        },
        _linkTreeNodes: function($sourceTree, $visualTree) {
            var $visualNodes = $visualTree.find("*"),
                $sourceNodes = $sourceTree.find("*");
            for(var i = $sourceNodes.length - 1; i >= 0; i--) {
                if(this._isTemplateContent($($sourceNodes[i])))
                    continue;

                $($visualNodes[i]).data("sourceNode", $sourceNodes[i]);
                $($sourceNodes[i]).data("visualNode", $visualNodes[i]);

                var visualNodeMarkClass = "visualNodeMarkClass-" + Math.random().toString().replace('0.', '');
                $($visualNodes[i]).addClass(visualNodeMarkClass);
                $($sourceNodes[i]).data("visualNodeMarkClass", visualNodeMarkClass);
            };
        },
        _isTemplateContent: function($node) {
            while($node && $node.length > 0) {
                var dataOptions = $node.attr('data-options');
                if(dataOptions && (dataOptions.indexOf('dxTemplate') == 0 || dataOptions.indexOf('dxItem') == 0))
                    return true;
                $node = $node.parent();
            }
            return false;
        }
    });

})(DevExpress);