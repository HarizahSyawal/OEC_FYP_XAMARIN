﻿(function(DX) {

    DX.designer.DragDropManager = function(selectionTitle, treesExplorer, metadata, scaleProvider) {
        var dragNode = null,
            currentDropInfo,
            positionEvaluator = DX.designer.createDropPositionEvaluator(treesExplorer, metadata, scaleProvider),
            $dropPositionMarker = $('#dropPositionMarker');
        
        function drop(dropInfo, dragSource) {
            if(dragNode) {
                if($.containsOrSame(dragNode, dropInfo.$targetNode[0])) {
                    return;
                }
                $(dragNode).remove();
            }
            var objectToAdd = $.parseHTML(dragSource);
            switch(dropInfo.position) {
                case DX.designer.DropPositions.before:
                    dropInfo.$targetNode.before(objectToAdd);
                    break;
                case DX.designer.DropPositions.after:
                    dropInfo.$targetNode.after(objectToAdd);
                    break;
                case DX.designer.DropPositions.inside:
                    dropInfo.$targetNode.append(objectToAdd);
                    break;
                case DX.designer.DropPositions.join:
                    var targetData = dropInfo.$targetNode.attr('data-bind');
                    var dropData = $(objectToAdd).attr('data-bind');
                    dropInfo.$targetNode.attr('data-bind', targetData + ', ' + dropData);
                    objectToAdd = dropInfo.$targetNode;
                    break;
            }
            resetDragDrop();
            return $(objectToAdd);
        }
        
        function dragOver(args) {
            var meta = getDragObjectMetadata(args.dragSource);
            if(meta && meta.isCommand()) {
                return;
            }

            var point = scaleProvider.adjustedPoint(args.targetPoint),
                pointOwner = args.targetWindow.document.elementFromPoint(point.x, point.y);
            if(pointOwner === $dropPositionMarker[0]) {
                return;
            }
            var dropInfo = positionEvaluator.getNodeInsertInfo($(pointOwner), scaleProvider.fromFrameToMainWindow(args.targetPoint), meta)
            if(currentDropInfo && currentDropInfo.position === dropInfo.position && currentDropInfo.$targetNode[0] === dropInfo.$targetNode[0]) {
                showMarker();
                return;
            }

            var $target = treesExplorer.visualNode(dropInfo.$targetNode),
                offset = positionEvaluator.getDropInsertCoordinates(dropInfo);
            showMarker();
            setMarkerPosition(offset, $target.outerHeight(), scaleProvider.nodeBoundsInMainWindow(treesExplorer.$visualTree()));
            currentDropInfo = dropInfo;
        }

        function setMarkerPosition(offset, targetNodeHeight, dxContentBounds) {
            var height = targetNodeHeight * scaleProvider.scale(),
                left = offset.left,
                top = offset.top;

            if(offset.left > dxContentBounds.x2) {
                left = dxContentBounds.x2;
            } else if(offset.left < dxContentBounds.x1) {
                left = dxContentBounds.x1
            }

            if(offset.top < dxContentBounds.y1) {
                height = height - (dxContentBounds.y1 - offset.top);
                top = dxContentBounds.y1
            } else if(offset.top + height > dxContentBounds.y2) {
                height = dxContentBounds.y2 - offset.top
            }

            $dropPositionMarker.css({
                left: left,
                top: top,
                height: height
            });
        }

        function showMarker() {
            selectionTitle.hideTitle();
            $dropPositionMarker.show();
        }
        function hideMarker() {
            $dropPositionMarker.hide();
            var $selected = treesExplorer.selectedSourceNode();
            selectionTitle.showTitle($selected, treesExplorer.selectedVisualNode(), metadata.byNode($selected));
        }

        function getDropInfo(args) {
            var meta = getDragObjectMetadata(args.dragSource);
            if(meta && meta.isCommand()) {
                var $dxViewChildren = treesExplorer.dxView().children();
                if($dxViewChildren.length === 0) {
                    return {
                        $targetNode: treesExplorer.dxView(),
                        position: DX.designer.DropPositions.inside
                    };
                }
                return {
                    $targetNode: $dxViewChildren.eq(0),
                    position: DX.designer.DropPositions.before
                };
            }   

            var point = scaleProvider.adjustedPoint(args.targetPoint),
                pointOwner = args.targetWindow.document.elementFromPoint(point.x, point.y);
            if(pointOwner === $dropPositionMarker[0]) {
                return currentDropInfo;
            }
            var info = positionEvaluator.getNodeInsertInfo($(pointOwner), scaleProvider.fromFrameToMainWindow(args.targetPoint), meta);
            info.$draggedNode = $(dragNode);
            return info;
        }
        function getDragObjectMetadata(dragSource) {
            return dragNode ? metadata.byNode($(dragNode)) : metadata.byHtml(dragSource);
        }

        function resetDragDrop() {
            dragNode = null;
            currentDropInfo = null;
            hideMarker();
        }

        function initVisualRootForDrag() {
            var scrollInProcess = false,
                $viewRoot = treesExplorer.$visualTree();
            $viewRoot.off('mousedown').on('mousedown', function(event) {
                var $node = treesExplorer.closestSourceNode($.originalEvent(event).srcElement);
                if(metadata.getDxTypeByNode($node) === "dxScrollView" || metadata.getDxTypeByNode($node) === "dxList") {
                    scrollInProcess = true;
                    selectionTitle.hideTitle();
                    return;
                }
                trySetDragNode($node, $.originalEvent(event).buttons);
            });
            $viewRoot.off('mousemove').on('mousemove', onDragSourceMouseMove);
            $viewRoot.off('mouseup').on('mouseup', function(event) {
                scrollInProcess = false;
                resetDragDrop();
            });

            treesExplorer.$visualTree().off('dragleave').on('dragleave', function(event) {
                var originalEvent = $.originalEvent(event),
                    cursorPoint = {
                        x: originalEvent.clientX / scaleProvider.scale(),
                        y: originalEvent.clientY / scaleProvider.scale()
                    },
                    $visualTree = treesExplorer.$visualTree();
                if(cursorPoint.x < 0 || cursorPoint.y < 0 || cursorPoint.x > $visualTree.outerWidth() || cursorPoint.y > $visualTree.outerHeight()) {
                    hideMarker();
                }
            });
        }
        function initSelectionTitleForDrag() {
            selectionTitle.$title().off('mousedown').on('mousedown', function(event) {
                trySetDragNode(treesExplorer.selectedSourceNode(), $.originalEvent(event).buttons);
            });
            selectionTitle.$title().off('mousemove').on('mousemove', onDragSourceMouseMove);
            selectionTitle.$title().off('mouseup').on('mouseup', resetDragDrop);
        }
        var onDragSourceMouseMove = function(event) {
            if(dragNode) {
                var $dragNode = $(dragNode);
                $dragNode.on('dragstart', onDragStart);
                dragNode.dragDrop();
                $dragNode.off('dragstart', onDragStart);
                resetDragDrop();
            }
        }
        function onDragStart(event) {
            if(dragNode) {
                event.originalEvent.dataTransfer.setData("Text", dragNode.outerHTML);
                event.originalEvent.dataTransfer.effectAllowed = "move";
            }
        }
        function trySetDragNode($node, buttons) {
            if(!$.isExist($node)) {
                return;
            }
            var nodeMeta = metadata.byNode($node);
            if(buttons === 1 && nodeMeta.isDraggable) {
                dragNode = $node[0];
            }
        }

        return {
            initViewRootNodeForDrag: initVisualRootForDrag,
            initSelectionTitleForDrag: initSelectionTitleForDrag,
            drop: drop,
            dragOver: dragOver,
            getDropPositionInfo: getDropInfo,

            _setDragNode: function(node) { dragNode = node; },
            _setMarkerPosition: setMarkerPosition
        }
    };

    DX.designer.DragDropEvents = function() {
        var onDrop = $.Callbacks(),
            onDragOver = $.Callbacks();

        var setDropAllow = function(event, isDropAllow) {
            if(isDropAllow && event.preventDefault) {
                event.preventDefault();
            }
            event.dataTransfer.dropEffect = isDropAllow ? "copy" : "none";
            event.returnValue = !isDropAllow;
        };

        var linkHandlers = function($targetElement, targetWindow) {
            $targetElement.on('dragover', function() {
                var isDropAllow = JSON.parse(externalProcessCommand({ command: "queryDropAllowed" })) === true;
                if (targetWindow === DevExpress.designer.frameWindow && isDropAllow) {
                    onDragOver.fire(getDropArgs(targetWindow));
                }
                setDropAllow(targetWindow.event, isDropAllow);
                return !isDropAllow;
            });
            $targetElement.on('drop', function() {
                onDrop.fire(getDropArgs(targetWindow));
                targetWindow.event.returnValue = false;
                return false;
            });
        };
        
        var getDropArgs = function(targetWindow) {
            return {
                targetWindow: targetWindow,
                targetPoint: { 'x': targetWindow.event.clientX, 'y': targetWindow.event.clientY },
                dragSource: targetWindow.event.dataTransfer.getData("Text")
            };
        };

        var initDesignerForDragDrop = function() {
            linkHandlers(findInFrame("body"), DevExpress.designer.frameWindow);
            linkHandlers($("#commands-panel"), window);
            linkHandlers($("#dropPositionMarker"), window);
        };

        initDesignerForDragDrop();
        return {
            onDrop: onDrop,
            onDragOver: onDragOver
        };
    }
})(DevExpress);