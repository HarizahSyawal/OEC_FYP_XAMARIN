﻿(function(DX) {
    DX.designer.createTreesExplorer = DesignerTreesExplorer;

    function DesignerTreesExplorer(selectedNodeClass) {
        var selectedNodeSelector = '.' + selectedNodeClass,
            dxViewSelector = '[data-dx-role="view"],:dxElement(dxView)',
            dxContentSelector = '[data-dx-target-placeholder],:dxElement(dxContent)',
            $visualTree = findInFrame("#visualTree-content"),
            $sourceTree = $("#sourceTree-content"),
            $commandsPanel = $("#commands-panel"),
            $dxView = null,
            $dxContentElements = null,
            $dxContainers = null;

        function visualNode(sourceNode) {
            if($(sourceNode)[0] === dxView()[0]) {
                return $visualTree;
            }
            var $visualNode = $($(sourceNode).data('visualNode'));
            if(isVisualNodeExistInView($visualNode)) {
                return $visualNode;
            }
            $visualNode = visualNodeByMark(sourceNode);
            if(isVisualNodeExistInView($visualNode)) {
                return $visualNode;
            }
            return $([]);
        }
        function visualNodeByMark(sourceNode) {
            var visualNodeMarkClass = $(sourceNode).data('visualNodeMarkClass');
            return $visualTree.find('.' + visualNodeMarkClass);
        }
        function sourceNode(visualNode) {
            if($(visualNode)[0] === $visualTree[0]) {
                return dxView();
            }
            var sourceNode = $($(visualNode).data('sourceNode'));
            if(sourceNode.length > 0) {
                return sourceNode;
            } else {
                return sourceNodeByMark(visualNode);
            }
        }
        function sourceNodeByMark(visualNode) {
            var sourceNode = $(),
                visualNodeMarkClass = null;

            if(visualNode.length > 0) {
                var classValue = $(visualNode).attr('class');
                if(classValue) {
                    $.each(classValue.split(/\s+/), function(index, value) {
                        if(value.toString().indexOf('visualNodeMarkClass') == 0) {
                            visualNodeMarkClass = value;
                        }
                    });
                    if(visualNodeMarkClass) {
                        $.each($sourceTree.find('*'), function(index, value) {
                            if($(value).data('visualNodeMarkClass') == visualNodeMarkClass) {
                                sourceNode = $(value);
                            }
                        });
                    }
                }
            }
            return sourceNode;
        }
        function isVisualNodeExistInView(visualNode) {
            return $commandsPanel.find(visualNode).length || $visualTree.find(visualNode).length || $(visualNode)[0] === $visualTree[0];
        }

        function closestSourceNode(visualNode) {
            var $toCheck = $(visualNode), $sourceNode;
            do {
                $sourceNode = sourceNode($toCheck);
                $toCheck = $toCheck.parent();
            }
            while($toCheck.length && !$sourceNode.length);
            return $sourceNode;
        }
        function closestVisualNode(sourceNode) {
            var $toCheck = $(sourceNode), $visualNode;
            do {
                $visualNode = visualNode($toCheck);
                $toCheck = $toCheck.parent();
            }
            while($toCheck.length && !isVisualNodeExistInView($visualNode))
            return $visualNode;
        }

        function sourceNodeIndex($node) {
            if($node && $node.length) {
                return $sourceTree.find("*").index($node);
            }
            return -1;
        }
        function sourceNodeByIndex(index) {
            return $sourceTree.find("*").eq(index);
        }
        function visualNodeBySourceIndex(index) {
            return this.visualNode(this.sourceNodeByIndex(index));
        }

        function selectedSourceNode(){
            return sourceNode(selectedVisualNode());
        }
        function selectedVisualNode() {
            if($visualTree.hasClass(selectedNodeClass)) {
                return $visualTree;
            }
            var $selectedNode = $visualTree.findWithRoot(selectedNodeSelector);
            if($selectedNode.length > 1) {
                var $activeView = $visualTree.findWithRoot(".dx-active-view");
                $selectedNode = !$activeView.length ? $selectedNode.eq(0) :
                    $activeView.findWithRoot(selectedNodeSelector);
            }
            return $selectedNode.length ? $selectedNode : $commandsPanel.find(selectedNodeSelector);
        }

        function dxView() {
            if (!$dxView) {
                $dxView = $sourceTree.find(dxViewSelector).eq(0);
            }
            return $dxView;
        }
        function isDxView(node) {
            return node === dxView().get(0);
        }

        function dxContentElements() {
            if (!$dxContentElements) {
                $dxContentElements = $(dxView()).children(dxContentSelector);
            }
            return $dxContentElements;
        }

        function dxContainers() {
            if(!$dxContainers) {
                $dxContainers = $visualTree.find(".dx-command-container:not(.dx-inactive-view .dx-command-container)");
            }
            return $dxContainers;
        }

        function refresh() {
            $dxView = null;
            $dxContentElements = null;
        }

        return {
            visualNode: visualNode,
            sourceNode: sourceNode,
            closestSourceNode: closestSourceNode,
            closestVisualNode: closestVisualNode,
            sourceNodeIndex: sourceNodeIndex,
            sourceNodeByIndex: sourceNodeByIndex,
            visualNodeBySourceIndex: visualNodeBySourceIndex,
            selectedSourceNode: selectedSourceNode,
            selectedVisualNode: selectedVisualNode,
            $sourceTree: function() { return $sourceTree; },
            $visualTree: function() { return $visualTree; },
            $commandsPanel: function() { return $commandsPanel; },
            dxView: dxView,
            isDxView: isDxView,
            dxContentElements: dxContentElements,
            dxContainers: dxContainers,
            refresh: refresh
        }
    }
})(DevExpress);