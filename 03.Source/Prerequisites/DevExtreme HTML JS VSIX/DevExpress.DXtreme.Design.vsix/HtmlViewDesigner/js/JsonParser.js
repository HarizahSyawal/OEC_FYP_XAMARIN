﻿(function(DX) {
    var json_parse = (function() {
        "use strict";
        var at,
            ch,
            escapee = {
                '\'': '\\\'',
                '"': '\\"',
                '\\': '\\\\',
                '/': '/',
                b: '\b',
                f: '\f',
                n: '\n',
                r: '\r',
                t: '\t'
            },
            text,

            error = function(m) {
                throw {
                    name: 'SyntaxError',
                    message: "Unable to parse bindings.\nMessage: " + m + ";\nBindings value: " + text + ";\nSuccessfully parsed part: " + text.slice(0, at)
                };
            },

            next = function(c) {
                if(c && c !== ch) {
                    error("Expected '" + c + "' instead of '" + ch + "'");
                }
                ch = text.charAt(at);
                at += 1;
                return ch;
            },

            number = function() {
                var number,
                    string = '';

                if(ch === '-') {
                    string = '-';
                    next('-');
                }
                while(ch >= '0' && ch <= '9') {
                    string += ch;
                    next();
                }
                if(ch === '.') {
                    string += '.';
                    while(next() && ch >= '0' && ch <= '9') {
                        string += ch;
                    }
                }
                if(ch === 'e' || ch === 'E') {
                    string += ch;
                    next();
                    if(ch === '-' || ch === '+') {
                        string += ch;
                        next();
                    }
                    while(ch >= '0' && ch <= '9') {
                        string += ch;
                        next();
                    }
                }
                number = +string;
                if(!isFinite(number)) {
                    error("Bad number");
                } else {
                    white();
                    if(!isEndObjectDelemiter(ch)) {
                        return number + word();
                    } else {
                        return number;
                    }
                }
            },
            isEndObjectDelemiter = function(c) {
                return c === ")" || c === "}" || c === "]" || c === "," || c === ":" || c === "\r";
            },
            isStringDelemiter = function(c) {
                return c === '"' || c === "'";
            },

            string = function() {
                var hex,
                    i,
                    string = ch,
                    uffff,
                    currenttringDelemiter = ch;
                if(isStringDelemiter(ch)) {
                    while(next()) {
                        if(ch === currenttringDelemiter) {
                            string += ch;
                            next();
                            white();
                            if(!isEndObjectDelemiter(ch)) {
                                var res = string + word()
                                return res;
                            } else {
                                return string;
                            }
                        }
                        if(ch === '\\') {
                            next();
                            if(ch === 'u') {
                                uffff = 0;
                                for(i = 0; i < 4; i += 1) {
                                    hex = parseInt(next(), 16);
                                    if(!isFinite(hex)) {
                                        break;
                                    }
                                    uffff = uffff * 16 + hex;
                                }
                                string += String.fromCharCode(uffff);
                            } else if(typeof escapee[ch] === 'string') {
                                string += escapee[ch];
                            } else {
                                break;
                            }
                        } else {
                            string += ch;
                        }
                    }
                }
                error("Bad string");
            },

            white = function() {
                while(ch && ch <= ' ') {
                    next();
                }
            },
            functionExp = function() {
                return statementEnclosedInSymbols("(", ")");
            },
            functionBody = function() {
                return statementEnclosedInSymbols("{", "}");
            },
            statementEnclosedInSymbols = function(startSymbol, endSymbol) {
                var result = "";
                while(ch) {
                    if(ch === endSymbol) {
                        result += ch;
                        next();
                        return result;
                    } else if(isStringDelemiter(ch)) {
                        result += string();
                    } else {
                        result += ch;
                        next();
                    }
                    if(ch === startSymbol) {
                        result += statementEnclosedInSymbols(startSymbol, endSymbol);
                    }
                }
            },

            conditionalOperator = function() {
                var result = ch;
                result += next('?');
                result += value();
                result += ch;
                result += next(':');
                result += value();
                return result;
            },

            word = function() {
                var result = "";
                while(ch) {
                    if(ch === "(") {
                        result += functionExp();
                    } else if(ch === '{') {
                        result += functionBody();
                    } else if(isEndObjectDelemiter(ch)) {
                        return $.trim(result);
                    }
                    else if(isStringDelemiter(ch)) {
                        result += string();
                    }
                        //else if(ch >= '0' && ch <= '9') {
                        //    result += number();
                        //}
                    else if(ch === '?') {
                        result += conditionalOperator();
                    }
                    else if(ch === '[') {
                        result += ch;
                        next('[');
                        result += value();
                        result += ch;
                        next(']');
                    }
                    else {
                        result += ch;
                        next();
                    }
                }
            },

            value,

            parseArray = function(item) {
                var array = [];
                if(ch === '[') {
                    next('[');
                    white();
                    while(ch) {
                        if(ch === ']') {
                            next(']');
                            return array;
                        }
                        array.push(item());
                        white();
                        if(ch === ']') {
                            next(']');
                            return array;
                        }
                        next(',');
                        white();
                    }
                }
                error("Bad array");
            },

            array = function() {
                return parseArray(value);
            },

            normalizeKey = function(key) {
                if((key.charAt(0) === "'" && key.charAt(key.length - 1) == "'") ||
                    (key.charAt(0) === "\"" && key.charAt(key.length - 1) == "\"")) {
                    return key.slice(1, key.length - 1);
                }
                return key;
            },

            getKey = function() {
                if(ch === '"' || ch === "'") {
                    return normalizeKey(string());
                } else {
                    var key = "";
                    while(ch) {
                        if(ch === ":") {
                            return $.trim(key);
                        }
                        key += ch;
                        next();
                    }
                }
            },
            object = function() {
                var key,
                    object = {};

                if(ch === '{') {
                    next('{');
                    white();
                    if(ch === '}') {
                        next('}');
                        return object;
                    }
                    while(ch) {
                        key = getKey();
                        white();
                        next(':');
                        if(Object.hasOwnProperty.call(object, key)) {
                            error('Duplicate key "' + key + '"');
                        }
                        object[key] = value();
                        white();
                        if(ch === ',') {
                            next(',');
                        }
                        white();
                        if(ch === '}') {
                            next('}');
                            return object;
                        }
                    }
                }
                error("Bad object");
            },
            clear = function(source) {
                text = source;
                at = 0;
                ch = ' ';
            };

        value = function() {
            white();
            switch(ch) {
                case '{':
                    return object();
                case '[':
                    return array();
                case '"':
                    return string();
                case "'":
                    return string();
                case '-':
                    return number();
                default:
                    return ch >= '0' && ch <= '9' ? number() : word();
            }
        };

        return {
            parse: function(source, reviver) {
                var result;
                clear(source);
                result = value();
                white();
                if(ch) {
                    error("Syntax error");
                }
                return typeof reviver === 'function'
                    ? (function walk(holder, key) {
                        var k, v, value = holder[key];
                        if(value && typeof value === 'object') {
                            for(k in value) {
                                if(Object.prototype.hasOwnProperty.call(value, k)) {
                                    v = walk(value, k);
                                    if(v !== undefined) {
                                        value[k] = v;
                                    } else {
                                        delete value[k];
                                    }
                                }
                            }
                        }
                        return reviver.call(holder, key, value);
                    }({ '': result }, ''))
                    : result;
            },
            parseArray: function(source) {
                clear(source);
                white();
                return parseArray(word);
            }
        }
    }());
    DX.designer.json_parse = json_parse.parse;
    DX.designer.json_parseArray = json_parse.parseArray;
})(DevExpress);
