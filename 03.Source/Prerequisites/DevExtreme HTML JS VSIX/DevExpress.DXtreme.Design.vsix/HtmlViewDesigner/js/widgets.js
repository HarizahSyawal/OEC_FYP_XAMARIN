﻿(function(DX, undefined) {

    DX.designer["13.1"].widgets = {
        "dxButton": "<div data-bind=\"dxButton: { text: 'Button1' }\"></div>",
        "dxNavBar": "<div data-bind=\"dxNavBar: { items: [ { text: 'home', icon: 'home', clickAction: alert }] }\"></div>",
        "dxRangeSlider": "<div data-bind=\"dxRangeSlider: {}\"></div>",
        "dxTabs": "<div data-bind=\"dxTabs: { items: [{ text: 'home', icon: 'home' }, { text: 'about', icon: 'info' } ] }\"></div>",
        "dxLookup": "<div data-bind=\"dxLookup: {}\"></div>",
        "dxToolbar": "<div data-bind=\"dxToolbar: { items: [ { align: 'left', widget: 'button', options: { type: 'back', text: 'Back', clickAction: alert } }, { align: 'center', text: 'Title' } ] }\"></div>",
        "dxSwitch": "<div data-bind=\"dxSwitch: { }\"></div>",
        "dxSlider": "<div data-bind=\"dxSlider: { }\"></div>",
        "dxScrollView": {
            html: "<div data-bind=\"dxScrollView: { }\"></div>",
            options: { isContainer: true }
        },
        "dxGallery": "<div data-bind=\"dxGallery: { items: [{ title: 'Item1' }, { title: 'Item2' }] }\" style=\"height: 150px;\">" +
                        "<div data-options=\"dxTemplate : { name: 'item' } \">" +
                            "<div data-bind=\"text: title\" style=\"background: yellow; width: 100px; height: 100px; margin: 10px;\"></div>" +
                        "</div>" +
                    "</div>",
        "dxList": "<div data-bind=\"dxList: { dataSource: [{ key: 1, title: 'Item1'}, { key: 2, title: 'Item2' }] }\">" +
                       "<div data-options=\"dxTemplate : { name: 'item' } \" data-bind=\"dxAction: '#itemDetailsViewName/{key}'\">" +
                           "<div data-bind=\"text: title\"></div>" +
                       "</div>" +
                   "</div>",
        "dxTileView": "<div data-bind=\"dxTileView: { items: [ { title: 'Item1', widthRatio: 2, heightRatio: 2 }, { title: 'Item2', widthRatio: 2, heightRatio: 2 } ] }\">" +
                            "<div data-options=\"dxTemplate : { name: 'item' } \">" +
                                "<span data-bind=\"text: title\"></span>" +
                            "</div>" +
                        "</div>",
        "dxCommand": {
            html: "<div data-bind=\"dxCommand: { title: 'Command Title' }\"></div>",
            options: {
                isDraggable: false,
                isCommand: function() {
                    return true;
                },
                getTargetElement: function() {
                    return findInFrame("[data-dx-role='view'],:dxElement(dxView)");
                }
            }
        },
        "dxChart": "<div style=\"height: 300px;\" data-bind=\"dxChart: {dataSource: [{ \'arg\': \'milk\', \'val\': 2, \'val1\': 1, \'val2\': 3 }, { \'arg\': \'soda\', \'val\': 3, \'val1\': 4, \'val2\': 5 }], series: [{ \'name\': \'Series 1\', \'type\': \'bar\' }], commonSeriesSettings: { \'type\': \'bar\' } }\"></div>",
        "dxMap": "<div data-bind=\"dxMap: { }\"></div>",
        "dxTextBox": "<div data-bind=\"dxTextBox: {}\"></div>",
        "dxDateBox": "<div data-bind=\"dxDateBox: {}\"></div>",
        "dxNumberBox": "<div data-bind=\"dxNumberBox: {}\"></div>",
        "dxCheckBox": "<div data-bind=\"dxCheckBox: {}\"></div>",
        "dxActionSheet": "<div data-bind=\"dxActionSheet: { title: '', showTitle: true }\"></div>",
        "dxAutocomplete": "<div data-bind=\"dxAutocomplete: { dataSource: [{ text: 'Item1' }, { text: 'Item2' }], displayExpr: 'text' }\"></div>",
        "dxDropDownMenu": { html: null },
        "dxLoadPanel": "<div data-bind=\"dxLoadPanel: { message: 'Loading...' }\"></div>",
        "dxOverlay": { html: null },
        "dxPopup": "<div data-bind=\"dxPopup: { title: '', showTitle: true }\"></div>",
        "dxPieChart": "<div style=\"height: 300px;\" data-bind=\"dxPieChart: { dataSource: [{ arg: 'milk', val: 1 }, { arg: 'soda', val: 3 }], series: {} }\"></div>",
        "dxRangeSelector": "<div style=\"height:100px\" data-bind=\"dxRangeSelector: { scale: { endValue: 10, startValue: 0 } }\"></div>",
        "dxToast": "<div data-bind=\"dxToast: { }\"></div>",
        "dxTextArea": "<div data-bind=\"dxTextArea: { }\"></div>",
        "dxFieldset": {
            html: "<div class=\"dx-fieldset\">" +
                     "<div class=\"dx-field\">" +
                         "<div class=\"dx-field-label\">Caption</div>" +
                         "<div class=\"dx-field-value\">" +
                             "<div data-bind=\"dxTextBox:{ placeholder: 'Text' }\"></div>" +
                         "</div>" +
                     "</div>" +
                     "<div class=\"dx-field\">" +
                         "<div class=\"dx-field-label\">Caption</div>" +
                         "<div class=\"dx-field-value\">" +
                             "<div data-bind=\"dxTextBox:{ placeholder: 'Text' }\"></div>" +
                         "</div>" +
                     "</div>" +
                 "</div>",
            options: {
                isContainer: true,
                getTargetElement: function($node) {
                    var $fieldset = $node.closest(".dx-fieldset");
                    if($fieldset.length) {
                        return $fieldset.parent();
                    }
                    return this._base.getTargetElement($node);
                }
            }
        },
        "dxField": {
            html: "<div class=\"dx-field\">" +
                    "<div class=\"dx-field-label\">Caption</div>" +
                    "<div class=\"dx-field-value\">" +
                        "<div data-bind=\"dxTextBox:{ }\"></div>" +
                    "</div>" +
                   "</div>",
            options: {
                isContainer: true,
                getCommandData: DX.designer.metadata.fieldCommandData.get,
                setCommandData: DX.designer.metadata.fieldCommandData.set,
                getTargetElement: function($node) {
                    var $fieldset = $node.closest(".dx-fieldset");
                    if($fieldset.length) {
                        return $fieldset;
                    }
                    return this._base.getTargetElement($node);
                }
            }
        },
        "dxCircularGauge": "<div style=\"height:300px\" data-bind=\"dxCircularGauge: { needles: [{ value: 35 }] }\"></div>",
        "dxLinearGauge": "<div style=\"height:100px\" data-bind=\"dxLinearGauge: {needles:[{value: 35}]}\"></div>",
        "dxView": {
            html: null,
            options: {
                isContainer: true,
                isDraggable: false,
                propertiesAttr: "data-options"
            }
        }
    };

    DX.designer["13.2"].widgets = $.extend({ }, DX.designer["13.1"].widgets, {
        "dxAutocomplete": "<div data-bind=\"dxAutocomplete: { items: [{ text: 'Item1' }, { text: 'Item2' }], displayExpr: 'text' }\"></div>",
        "dxToolbar": "<div data-bind=\"dxToolbar: { items: [{ location: 'left', widget: 'button', options: { type: 'back', text: 'Back', clickAction: alert } }, { text: 'Title' }] }\"></div>",
        "dxCircularGauge": "<div style=\"height:300px\" data-bind=\"dxCircularGauge: { value: 35 }\"></div>",
        "dxLinearGauge": "<div style=\"height:100px\" data-bind=\"dxLinearGauge: { value: 35 }\"></div>",
        "dxBarGauge": "<div style=\"height:300px\" data-bind=\"dxBarGauge: { values: [60, 75, 40] }\"></div>",
        "dxPanorama": "<div data-bind=\"dxPanorama: { items: [ 'Item 1', 'Item 2', 'Item 3'] }\"></div>",
        "dxPivot": "<div data-bind=\"dxPivot: { items: [ 'Item 1', 'Item 2', 'Item 3'] }\"></div>",
        "dxPopover": "<div data-bind=\"dxPopover: { }\"></div>",
        "dxRadioGroup": "<div data-bind=\"dxRadioGroup: { items: [ 'Item 1', 'Item 2', 'Item 3'], layout: 'vertical' }\"></div>",
        "dxSelectBox": "<div data-bind=\"dxSelectBox: { items: [{ text: 'Item1' }, { text: 'Item2' }], displayExpr: 'text' }\"></div>",
        "dxSlideOut": "<div data-bind=\"dxSlideOut: { }\"></div>",
        "dxSparkline": "<div style=\"height: 100px;\" data-bind=\"dxSparkline: {dataSource: [4,8,6,9,4,5,6,4,6,9,4], tooltip: {enabled: false}}\"></div>",
        "dxBullet": "<div style=\"height: 50px;\" data-bind=\"dxBullet: {startScaleValue: 0, endScaleValue: 20, target: 10, value: 12, tooltip: {enabled: false}}\"></div>",
        "dxVectorMap": "<div style=\"height: 350px;\" data-bind=\"dxVectorMap: { mapData: null }\"></div>"
    });
    
    DX.designer["14.1"].widgets = $.extend(true, { }, DX.designer["13.2"].widgets, {
        "dxCommand": {
            html: null // remove dxCommand from toolbox
        },
        "dxCalendar": "<div data-bind=\"dxCalendar: { }\"></div>",
        "dxColorPicker": "<div data-bind=\"dxColorPicker: { }\"></div>",
        "dxDataGrid": "<div data-bind=\"dxDataGrid: { dataSource: [{ key: 1, title: 'Item1'}, { key: 2, title: 'Item2' }], columns: ['key', 'title'] }\"></div>",
        "dxLoadIndicator": "<div data-bind=\"dxLoadIndicator: { }\"></div>",
        "dxMultiView": "<div data-bind=\"dxMultiView: { height: 300, items: [{ text: 'item1' }, { text: 'item2' }] }\"></div>",
        "dxTooltip": "<div data-bind=\"dxTooltip: { }\"></div>",
        "dxMenu": "<div data-bind=\"dxMenu: { items: [{ text: 'item1', items: [{ text: 'item1.1' }] }, { text: 'item2' }] }\"></div>",
        "dxContextMenu": "<div data-bind=\"dxContextMenu: { }\"></div>",
        "dxToolbar": "<div data-bind=\"dxToolbar: { items: [{ location: 'before', options: { type: 'back', text: 'Back', clickAction: function() { alert('Back') } }, widget: 'button' }, { text: 'Title' }] }\"></div>",

        "dxTemplate": { html: null },
        "dxContentPlaceholder": { html: null },
        "dxContent": {
            html: null,
            options: {
                isContainer: true,
                isDraggable: false,
                propertiesAttr: "data-options"
            }
        },
        "dxViewPlaceholder": { html: null }
    });

    DX.designer["14.2"].widgets = $.extend(true, {}, DX.designer["14.1"].widgets, {
        "dxColorPicker": { html: null },
        "dxColorBox": "<div data-bind=\"dxColorBox: { value: '#ffffff' }\"></div>",
        "dxTreeView": "<div data-bind=\"dxTreeView: { items: [{ id: 1, text: 'Item1', items: [{ id: 3, text: 'Item1.1' }] }, { id: 2, text: 'Item2' }]}\"></div>",
        "dxAccordion": "<div data-bind=\"dxAccordion: { items: [{ title: 'Group1', text: 'Item1.1' }, { title: 'Group2', text: 'Item2.1' }] }\"></div>",
        "dxTabPanel": "<div data-bind=\"dxTabPanel: { items: [{ title: 'Tab1', text: 'Item1.1' }, { title: 'Tab2', text: 'Item2.1' }] }\"></div>",
        "dxTagBox": "<div data-bind=\"dxTagBox: { items: [{ text: 'Item1' }, { text: 'Item2' }], displayExpr: 'text' }\"></div>",
        "dxProgressBar": "<div data-bind=\"dxProgressBar: { value: 50 }\"></div>",
        "dxFileUploader": "<div data-bind=\"dxFileUploader: { }\"></div>",
        "dxBox": "<div data-bind=\"dxBox: { direction: 'row' }\"><div data-options=\"dxItem: { baseSize: 0, ratio: 1 }\"><div>Content1</div></div><div data-options=\"dxItem: { baseSize: 0, ratio: 1  }\"><div>Content2</div></div></div>",
        "dxResponsiveBox": "<div data-bind=\"dxResponsiveBox: { rows: [{ ratio: 1 }, { ratio: 1 }], cols: [{ ratio: 1 }, { ratio: 1 }] }\"><div data-options=\"dxItem: { location: { row: 0, col: 0 } }\"><div>Content1</div></div><div data-options=\"dxItem: { location: { row: 0, col: 1 } }\"><div>Content2</div></div><div data-options=\"dxItem: { location: { row: 1, col: 0 } }\"><div>Content3</div></div><div data-options=\"dxItem: { location: { row: 1, col: 1 } }\"><div>Content4</div></div></div>",
        "dxItem": { html: null },
        "dxValidator": {
            html: "<div data-bind=\"dxValidator: {  }\"></div>",
            options: {
                isContainer: false,
                isDraggable: false,
                isJoinable: true,
                joinableWidgets: ["dxCalendar", "dxCheckBox", "dxRadioGroup", "dxNumberBox", "dxTextBox", "dxDropDownEditor", "dxColorPicker", "dxDropDownList", "dxAutocomplete", "dxSelectBox", "dxLookup", "dxTextArea", "dxDateBox"]
            }
        },
        "dxValidationGroup": "<div data-bind=\"dxValidationGroup: {  }\"></div>",
        "dxValidationSummary": "<div data-bind=\"dxValidationSummary: {  }\"></div>",
        "dxPolarChart": "<div style=\"height: 300px;\" data-bind=\"dxPolarChart: { dataSource: [{ \'arg\': \'milk\', \'val\': 4 }, { \'arg\': \'soda\', \'val\': 3 }, { \'arg\': \'water\', \'val\': 4 }, { \'arg\': \'juice\', \'val\': 3 }, { \'arg\': \'cocktail\', \'val\': 4 }, { \'arg\': \'syrup\', \'val\': 3} ], series: [{ \'name\': \'Series 1\', \'type\': \'bar\' }] }\"></div>"
    });

    DX.designer["15.1"].widgets = $.extend(true, {}, DX.designer["14.2"].widgets, {
        "dxPivotGrid": "<div data-bind=\"dxPivotGrid: { dataSource: { store: [{ key: 1, title: 'Item1'}, { key: 2, title: 'Item2' }], fields: [{ dataField: 'title', area: 'column'}, { dataField: 'key', area: 'row'}, { summaryType: 'count', area: 'data'}]} }\"></div>",
        "dxScheduler": "<div data-bind=\"dxScheduler: { dataSource: [ { text: 'Happy New Year!', startDate: new Date(2015, 0, 1, 0, 0, 0), endDate: new Date(2015, 0, 1, 0, 30, 0) } ], currentDate: new Date(2015, 0, 1) }\"></div>",
        "dxResizable": "<div style=\"width: 50%; height: 50%; background: gold; \" data-bind=\"dxResizable: { }\">Resizable</div>",
        "dxDeferRendering": {
            html: "<div data-bind=\"dxDeferRendering: { showLoadIndicator: true }\"></div>",
            options: {
                isContainer: true
            }
        },
        "dxSlideOutView": "<div data-bind=\"dxSlideOutView: {  }\"></div>",
        "dxPivotGridFieldChooser": "<div data-bind=\"dxPivotGridFieldChooser: {  }\"></div>"
    });

    DX.designer["15.2"].widgets = $.extend(true, {}, DX.designer["15.1"].widgets, {
        "dxForm": "<div data-bind=\"dxForm: { formData: { login: 'admin', password: '123' } }\"></div>",
        "dxTreeMap": "<div style=\"height: 300px;\" data-bind=\"dxTreeMap: { dataSource: [{ name: 'milk', value: 1 }, { name: 'soda', value: 3 }] }\"></div>",
        "dxVectorMap": "<div style=\"height: 350px;\" data-bind=\"dxVectorMap: {  }\"></div>",
        "dxAutocomplete": "<div data-bind=\"dxAutocomplete: { items: [{ text: 'Item1' }, { text: 'Item2' }], valueExpr: 'text' }\"></div>"
    });

    DX.designer["17.1"].widgets = $.extend(true, {}, DX.designer["15.2"].widgets, {
        "dxToolbar": "<div data-bind=\"dxToolbar: { items: [{ location: 'before', options: { type: 'back', text: 'Back', clickAction: function() { alert('Back') } }, widget: 'dxButton' }, { text: 'Title' }] }\"></div>",
        "dxTreeList": "<div data-bind=\"dxTreeList: { dataSource: [{ id: 1, parentId: 0, title: 'Item1' }, { id: 2, parentId: 1, title: 'Item2' }], columns: ['id', 'title'] }\"></div>"
    });

    DX.designer["17.2"].widgets = $.extend(true, {}, DX.designer["17.1"].widgets, {
        "dxFunnel": "<div style=\"height: 300px;\" data-bind=\"dxFunnel: { dataSource: [{ arg: 'start', val: 20 }, { arg: 'end', val: 10 }] }\"></div>",
        "dxFilterBuilder": "<div data-bind=\"dxFilterBuilder: { fields: [{ dataField: 'MyField' }] }\"></div>",
        "dxDropDownBox": "<div data-bind=\"dxDropDownBox: { }\"><div data-options=\"dxTemplate: { name: 'content' }\"></div></div>"
    });
    
    DX.designer["18.1"].widgets = $.extend(true, {}, DX.designer["17.2"].widgets, {
        
    });

    DX.designer["18.2"].widgets = $.extend(true, {}, DX.designer["18.1"].widgets, {
        
    });

    //only for tests
    DX.designer._registerWidgets = function() {
        DX.designer.metadata.registerWidgets(DX.designer["17.1"].widgets);
    }
})(DevExpress);