﻿(function(DX) {
    function scaleProvider(simulator, $iframe) {

        function nodeBoundsInMainWindow($node) {
            var scale = getScale(),
                nodeOffset = nodeOffsetInMainWindow($node);

            var nodeBounds = {
                x1: nodeOffset.left,
                y1: nodeOffset.top,
                width: $node.outerWidth() * scale,
                height: $node.outerHeight() * scale
            };
            nodeBounds.x2 = nodeBounds.x1 + nodeBounds.width;
            nodeBounds.y2 = nodeBounds.y1 + nodeBounds.height;
            return nodeBounds;
        }

        function nodeOffsetInMainWindow($node) {
            var offset = $node.offset(),
                point = fromFrameToMainWindow({ x: offset.left, y: offset.top });
            return { 'left': point.x, 'top': point.y };
        }
        function fromFrameToMainWindow(point) {
            var scale = getScale(),
                iframeOffset = getFrameOffset(),
                result = { x: point.x, y: point.y };
            if(document.documentMode >= 10) {
                result.x = result.x * scale;
                result.y = result.y * scale;
            }
            result.x += iframeOffset.left;
            result.y += iframeOffset.top;
            return result;
        }

        function adjustedPoint(point) {
            var scale = document.documentMode < 10 ? getScale() : 1;
            return { x: point.x / scale, y: point.y / scale };
        }

        function getFrameOffset() {
            if($.isExist($iframe)) {
                return $iframe.offset();
            }
            return { 'left': 0, 'top': 0 };
        }

        function getScale() {
            if(simulator) {
                return simulator.getAbsoluteScale();
            }
            return 1;
        }

        return {
            scale: getScale,
            nodeBoundsInMainWindow: nodeBoundsInMainWindow,
            fromFrameToMainWindow: fromFrameToMainWindow,
            nodeOffsetInMainWindow: nodeOffsetInMainWindow,
            adjustedPoint: adjustedPoint
        }
    }

    DX.designer.scaleProvider = scaleProvider;
})(DevExpress);