﻿/// <reference path="globalize.min.js" />
/// <reference path="jquery.js" />
(function(DX) {

    DX.designer.commands.Mapper = function(config, frameworkAdapter) {
        if(CommandsMapper.prototype._singletonInstance) {
            CommandsMapper.prototype._singletonInstance._setOptions(config, frameworkAdapter);
            return CommandsMapper.prototype._singletonInstance;
        }
        return CommandsMapper(config, frameworkAdapter);
    }

    function CommandsMapper(config, frameworkAdapter) {
        var $mappingPanel = $("#command-mapping-panel"),
            $cmdInput = $mappingPanel.find(".сommand-id input"),
            viewModel,
            configObject = $.extend(true, {}, config),
            mapHelper;

        function initializeAutocomplete() {
            var wasOpen = false;
            $cmdInput.on("mousedown", function() {
                wasOpen = $cmdInput.autocomplete("widget").is(":visible");
            }).on("click", function() {
                if(wasOpen) return;
                $cmdInput.autocomplete("search", "");
            });
        }

        $(function() {
            initializeAutocomplete();
            viewModel = (new DX.designer.commands.ViewModelBuilder('')).getViewModel();
            ko.applyBindings(viewModel, $mappingPanel[0]);
        });

        function addNewCommand(args) {
            mapHelper = new DX.designer.commands.addCommandHelper(args.$dxView);
            var viewModelBuilder = new DX.designer.commands.ViewModelBuilder(null, viewModel, true);
            showPanel(viewModelBuilder);
        }

        function editCommand(args) {
            mapHelper = new DX.designer.commands.editCommandHelper(args.$dxView);
            var viewModelBuilder = new DX.designer.commands.ViewModelBuilder(args.commandID, viewModel, false);
            showPanel(viewModelBuilder);
        }

        function showPanel(viewModelBuilder) {
            _retrieveLayouts(viewModelBuilder, frameworkAdapter.createViewEngine({}, $("<div />")));
            _retrieveCommandsFromConfig(frameworkAdapter.defaultMapping(), viewModelBuilder, mapHelper.needToAppendCommand);
            _retrieveCommandsFromConfig(configObject.commandMapping, viewModelBuilder, mapHelper.needToAppendCommand);
            viewModel = viewModelBuilder.getViewModel();

            if(viewModel.addCommandOperation) {

                $cmdInput[0].disabled = false;
                $cmdInput.autocomplete({
                    source: mapHelper.autocompleteSource(viewModel.commands),
                    minLength: 0,
                    select: function(event, ui) {
                        viewModel.selectedCommand(ui.item.value);
                        if(ui.item.value) {
                            $cmdInput[0].blur();
                            $cmdInput[0].readOnly = true;
                        } else {
                            $cmdInput[0].readOnly = false;
                            $cmdInput.focus();
                            $cmdInput.select();
                        }
                    },
                    disabled: false
                });

            } else {

                $cmdInput[0].disabled = true;
                $cmdInput[0].readOnly = true;

                $cmdInput.autocomplete({
                    disabled: true
                });

            }

            $mappingPanel.css("display", "inline-block");
            setMappingPanelPosition();
            $(window).on("resize", setMappingPanelPosition);
            $mappingPanel.width($mappingPanel.width());
            $cmdInput.focus();
        }

        function setMappingPanelPosition() {
            $mappingPanel.offset({
                top: ($(window).height() - $mappingPanel.height()) / 2 - $("#commands-panel").height(),
                left: ($(window).width() - $mappingPanel.width()) / 2
            });
        }

        function hidePanel() {
            $mappingPanel.hide();
            $(window).off("resize", setMappingPanelPosition);
        }

        function applyChanges() {
            var commandID = viewModel.selectedCommand();
            if(viewModel.addCommandOperation) {
                generateNativeCommand(commandID);
            } else {
                generateNativeCommand(commandID);
            }
        }

        function generateNativeCommand(commandID) {
            var newConfig;
            if(viewModel.isMappingChanged()) {
                var configFileName = externalProcessCommand({ command: "getConfigFileName" }),
                    configFileContent = loadFile(configFileName),
                    configJsonString = DX.designer.getAppConfigString(configFileContent, configFileName);

                configObject.commandMapping = _applyCommandToCommandMapping(configObject.commandMapping, getMappedConteinersForCommand(commandID), commandID);

                var newConfigObject = eval('(' + configJsonString + ')').config;
                newConfigObject.commandMapping = configObject.commandMapping;
                var newConfigStrng = DX.designer.utils.stringifyFormat({ config: newConfigObject });
                newConfig = configFileContent.replace(configJsonString, newConfigStrng);
            } else {
                newConfig = null;
            }
            viewDesigner = null;
            DX.designer.frameWindow.location.reload();            
            DX.designer.simulator.frame[0].onload = function() {
                    externalProcessCommand(mapHelper.createNativeCommand(newConfig, commandID));
                };
        }

        function getMappedConteinersForCommand(commandID) {
            var commandContainers = {};
            $.each(viewModel.layouts(), function(index, layout) {
                var mappedContainer = viewModel.commands[commandID].getMappedContainer(layout.layoutID);
                var mappedLocateInMenu = viewModel.commands[commandID].getMappedLocateInMenu(layout.layoutID)
                if(mappedContainer && !commandContainers[mappedContainer]) {
                    var arr = mappedContainer.split(" ");
                    commandContainers[arr[0]] = {
                        id: commandID,
                        location: arr.length === 2 ? arr[1] : undefined
                    }
                }
                if(mappedLocateInMenu) {
                    var arr = mappedLocateInMenu.split(" ");
                    if(!commandContainers[arr[0]])
                        commandContainers[arr[0]] = {
                            id: commandID
                        };
                    commandContainers[arr[0]]['locateInMenu'] = arr.length === 2 ? arr[1] : undefined;
                }
            });
            return commandContainers;
        }

        function okButtonHandler() {
            if(!mapHelper.checkSelectedCommandID(viewModel.selectedCommand())) {
                return;
            }
            hidePanel();
            if(viewModel.selectedCommand()) {
                applyChanges();
            }
        }

        $mappingPanel.find("#btn-cancel, #btn-close").on("click", function() {
            hidePanel();
        });
        $mappingPanel.find("#btn-ok").on("click", function() {
            okButtonHandler();
        });

        CommandsMapper.prototype._singletonInstance = {
            addNewCommand: addNewCommand,
            editCommand: editCommand,
            _setOptions: function(config, newFrameworkAdapter) {
                configObject = $.extend(true, {}, config);
                frameworkAdapter = newFrameworkAdapter;
            }
        };
        return CommandsMapper.prototype._singletonInstance;
    }

    function _applyCommandToCommandMapping(commandMappingObject, commandContainers, commandID) {
        var commandMapping = commandMappingObject || {};
        //update old command mappings
        $.each(commandMapping, function(containerID, containerObj) {
            containerObj.commands = $.map(containerObj.commands, function(command, index) {
                var newCommand = command;
                if(DX.designer.utils.isString(newCommand)) {
                    newCommand = { id: newCommand };
                }
                if(newCommand.id === commandID) {
                    if(commandContainers[containerID]) {
                        $.extend(newCommand, commandContainers[containerID]);
                        delete commandContainers[containerID];
                    } else {
                        newCommand = null;
                    }
                    return newCommand;
                }
                return command;
            });
        });

        //add new command mappings
        $.each(commandContainers, function(containerID, value) {
            commandMapping[containerID] = commandMapping[containerID] || { commands: [] };
            commandMapping[containerID].commands.push(value);
        });

        return commandMapping;
    }

    function _retrieveLayouts(viewModelBuilder, viewEngine) {
        var optionsAttr = viewEngine.dataOptionsAttributeName;
        $.each(viewEngine._templateMap, function(templateName, template) {
            if(!template.dxLayout) {
                return true;
            }

            $.each(template.dxLayout, function(index, layout) {
                var layoutName = buildLayoutName(templateName, layout._options.platform);
                $.each(layout._$element.find("[" + optionsAttr + "*=dxCommandContainer],[data-bind*=dxCommandContainer]"), function(_, container) {
                    var containerBinding = {};
                    $.each([optionsAttr, "data-bind"], function(_, attrName) {
                        var bindingString = $(container).attr(attrName);
                        if(bindingString) {
                            $.extend(containerBinding, DX.designer.BindingParser.knockoutBindingToObject(bindingString).patchedObject);
                        }
                    });
                    var containerID = containerBinding && containerBinding["dxCommandContainer"] ? containerBinding["dxCommandContainer"].id : null;
                    if(DX.designer.utils.isString(containerID) && containerID !== "global-navigation") {
                        if(containerBinding["dxToolbar"]) {
                            viewModelBuilder.mapContainerToLayout(layoutName, containerID + " before");
                            viewModelBuilder.mapContainerToLayout(layoutName, containerID + " center");
                            viewModelBuilder.mapContainerToLayout(layoutName, containerID + " after");
                            viewModelBuilder.mapLocateInMenuToLayout(layoutName, containerID + " always");
                            viewModelBuilder.mapLocateInMenuToLayout(layoutName, containerID + " never");
                            viewModelBuilder.mapLocateInMenuToLayout(layoutName, containerID + " auto");
                        } else {
                            viewModelBuilder.mapContainerToLayout(layoutName, containerID);
                        }
                    }
                });
            });
        });
    }

    function buildLayoutName(templateName, platform) {
        var layoutName = DX.designer.utils.capitaliseFirstLetter(templateName);
        if(platform) {
            layoutName += ' ' + (platform === "ios" ? "iOS" : DX.designer.utils.capitaliseFirstLetter(platform));
        }
        return layoutName;
    }

    function _retrieveCommandsFromConfig(commandMapping, viewModelBuilder, needToAppendCommand) {
        if(!commandMapping) return;
        $.each(commandMapping, function(containerID, container) {
            var defaultLocation = container.defaults ? container.defaults.location : undefined;
            var defaultLocateInMenu = null;
            if(!container.commands) return;
            $.each(container.commands, function(index, command) {
                if(!command) {
                    return;
                }

                var commandID, location, locateInMenu;
                if(DX.designer.utils.isString(command.id)) {
                    commandID = command.id;
                    location = command.location || defaultLocation;
                    locateInMenu = command.locateInMenu;
                } else if(DX.designer.utils.isString(command)) {
                    commandID = command;
                    location = defaultLocation;
                    locateInMenu = defaultLocateInMenu;
                }
                if(needToAppendCommand(commandID, containerID)) {
                    var locationLabel = containerID + (location ? (" " + location) : "");
                    var locateInMenuLabel = locateInMenu ? (containerID + " " + locateInMenu) : null;
                    viewModelBuilder.mapContainerToCommand(commandID, locationLabel);
                    viewModelBuilder.mapLocateInMenuToCommand(commandID, locateInMenuLabel);
                }
            });
        });
    }

    function findCommandsInView($dxView) {
        var commands = [];
        $.each(["data-options", "data-bind"], function(_, attrName) {
            $.each($dxView.find("[" + attrName + "^=dxCommand]"), function(index, command) {
                var bindingString = $(command).attr(attrName);
                if(bindingString) {
                    var bindingObject = DX.designer.BindingParser.knockoutBindingToObject(bindingString).patchedObject;
                    if(bindingObject && bindingObject.dxCommand && DX.designer.utils.isString(bindingObject.dxCommand.id)) {
                        commands.push(bindingObject.dxCommand.id);
                    }
                }
            });
        });
        return commands;
    }

    DX.designer.commands.Mapper._applyCommandToCommandMapping = _applyCommandToCommandMapping;
    DX.designer.commands.Mapper.findCommandsInView = findCommandsInView;
    DX.designer.commands.Mapper._retrieveCommandsFromConfig = _retrieveCommandsFromConfig;
    DX.designer.commands.Mapper._retrieveLayouts = _retrieveLayouts;
})(DevExpress);