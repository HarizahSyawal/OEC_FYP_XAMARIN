﻿/// <reference path="globalize.min.js" />
/// <reference path="jquery.js" />
(function(DX) {

    DX.designer.commands.ViewModelBuilder = ViewModelBuilder;

    function CommandMapping(layoutsDictionary) {
        this._layouts = layoutsDictionary;
        this._mappedContainers = {};
        this._mappedLocatesInMenu = {};
        var self = this;
        $.each(layoutsDictionary, function(layoutID, layout) {
            self.mapContainer(layoutID, null);
            self.mapLocateInMenu(layoutID, null);
        });
        this.isMappingChanged = false;
    }
    $.extend(CommandMapping.prototype, {
        mapContainer: function(layoutID, initialValue) {
            this._mappedContainers[layoutID] = {
                currentValue: initialValue,
                initialValue: initialValue
            }
        },
        mapLocateInMenu: function(layoutID, initialValue) {
            this._mappedLocatesInMenu[layoutID] = {
                currentValue: initialValue,
                initialValue: initialValue
            }
        },
        getMappedContainer: function(layoutID) {
            return this._mappedContainers[layoutID] && this._mappedContainers[layoutID].currentValue;
        },
        getMappedLocateInMenu: function(layoutID) {
            return this._mappedLocatesInMenu[layoutID] && this._mappedLocatesInMenu[layoutID].currentValue;
        },
        setContainerValue: function(layoutID, selectedValue) {
            var previousValue = this._mappedContainers[layoutID].currentValue,
                self = this;
            this.isMappingChanged = false;
            $.each(this._mappedContainers, function(layout, mappedContainer) {
                if(self._layouts[layout].containers.indexOf(selectedValue) > -1) {
                    mappedContainer.currentValue = selectedValue;
                    self._layouts[layout].selectedValueUpdater.notifySubscribers();
                } else if(mappedContainer.currentValue === previousValue) {
                    mappedContainer.currentValue = null;
                    self._layouts[layout].selectedValueUpdater.notifySubscribers();
                }
                if(mappedContainer.currentValue !== mappedContainer.initialValue) {
                    self.isMappingChanged = true;
                }
            });
        },
        setLocateInMenuValue: function(layoutID, selectedValue) {
            var previousValue = this._mappedLocatesInMenu[layoutID].currentValue,
                self = this;
            this.isMappingChanged = false;
            $.each(this._mappedLocatesInMenu, function(layout, mappedLocateInMenu) {
                if(self._layouts[layout].locatesInMenu.indexOf(selectedValue) > -1) {
                    mappedLocateInMenu.currentValue = selectedValue;
                    self._layouts[layout].selectedValueUpdater.notifySubscribers();
                } else if(mappedLocateInMenu.currentValue === previousValue) {
                    mappedLocateInMenu.currentValue = null;
                    self._layouts[layout].selectedValueUpdater.notifySubscribers();
                }
                if(mappedLocateInMenu.currentValue !== mappedLocateInMenu.initialValue) {
                    self.isMappingChanged = true;
                }
            });
        },
        applyChanges: function() {
            if(!this.isMappingChanged) {
                return;
            }
            $.each(this._mappedContainers, function(layoutID, mappedContainer) {
                mappedContainer.initialValue = mappedContainer.currentValue;
            });
            $.each(this._mappedLocatesInMenu, function(layoutID, mappedLocateInMenu) {
                mappedLocateInMenu.initialValue = mappedLocateInMenu.currentValue;
            });
            this.isMappingChanged = false;
        }
    });

    function Layout(layoutID, containers, parentViewModel) {
        this.layoutID = layoutID;
        this.containers = containers;
        this.locatesInMenu = [];
        this.selectedValueUpdater = ko.observable();
        this.selectedContainer = ko.computed({
            read: this.selectedContainerRead,
            write: this.selectedContainerWrite,
            deferEvaluation: true,
            owner: {
                selectedCommand: parentViewModel.selectedCommand,
                commands: parentViewModel.commands,
                isMappingChanged: parentViewModel.isMappingChanged,
                layoutID: layoutID,
                layouts: parentViewModel._layoutsDictionary,
                selectedValueUpdater: this.selectedValueUpdater
            }
        });
        this.selectedLocateInMenu = ko.computed({
            read: this.selectedLocateInMenuRead,
            write: this.selectedLocateInMenuWrite,
            deferEvaluation: true,
            owner: {
                selectedCommand: parentViewModel.selectedCommand,
                commands: parentViewModel.commands,
                isMappingChanged: parentViewModel.isMappingChanged,
                layoutID: layoutID,
                layouts: parentViewModel._layoutsDictionary,
                selectedValueUpdater: this.selectedValueUpdater
            }
        });
    }
    $.extend(Layout.prototype, {
        selectedContainerRead: function selectedContainerRead() {
            var command = this.commands[this.selectedCommand()];
            this.selectedValueUpdater();
            return command && command.getMappedContainer(this.layoutID);
        },
        selectedContainerWrite: function(value) {
            var commandID = this.selectedCommand();
            this.commands[commandID] = this.commands[commandID] || new CommandMapping(this.layouts);
            this.commands[commandID].setContainerValue(this.layoutID, value);
            this.isMappingChanged(this.commands[commandID].isMappingChanged);
        },
        selectedLocateInMenuRead: function() {
            var command = this.commands[this.selectedCommand()];
            this.selectedValueUpdater();
            return command && command.getMappedLocateInMenu(this.layoutID);
        },
        selectedLocateInMenuWrite: function(value) {
            var commandID = this.selectedCommand();
            this.commands[commandID] = this.commands[commandID] || new CommandMapping(this.layouts);
            this.commands[commandID].setLocateInMenuValue(this.layoutID, value);
            this.isMappingChanged(this.commands[commandID].isMappingChanged);
        }
    });

    function ViewModelBuilder(commandID, viewModel, addCommandOperation) {
        this._layoutsDictionary = {};
        if(viewModel) {
            this._viewModel = viewModel;
            this._clear(commandID);
        } else {
            this._createNew(commandID, true);
        }
        this._viewModel._layoutsDictionary = this._layoutsDictionary;
        this._viewModel.addCommandOperation = addCommandOperation;
        this._viewModel.title(addCommandOperation ? "Add Command" : "Edit Command");
        this._viewModel.originalCommandID = commandID;
    }
    $.extend(ViewModelBuilder.prototype, {
        _createNew: function(commandID) {
            var viewModel = this._viewModel = {
                selectedCommand: ko.observable(commandID),
                commands: {},
                layouts: ko.observable([]),
                isMappingChanged: ko.observable(false),
                title: ko.observable(),
                applyMappingChanges: function() {
                    this.commands[viewModel.selectedCommand()].applyChanges();
                    viewModel.isMappingChanged(false);
                },
                onAfterRender: function(element, layout) {

                    /* container */
                    var $containersCombo = $(element).filter("tr").find(".containers-combobox"),
                        wasOpen = false;
                    var containers = $.map(layout.containers, function(value, index) {
                        return {
                            label: value,
                            value: value
                        }
                    });
                    containers.push({
                        label: "<unmap>",
                        value: null
                    });
                    $containersCombo.autocomplete({
                        source: containers,
                        minLength: 0,
                        select: function(event, ui) {
                            layout.selectedContainer(ui.item.value);
                        }
                    });
                    $containersCombo.on("mousedown", function() {
                        wasOpen = $containersCombo.autocomplete("widget").is(":visible");
                    })
                    .on("click", function() {
                        if(wasOpen) return;
                        $containersCombo.autocomplete("search", "");
                    });

                    /* locate in menu */
                    var $locateInMenuCombo = $(element).filter("tr").find(".locate-in-menu-combobox");
                    var locatesInMenu = $.map(layout.locatesInMenu, function(value, index) {
                        return {
                            label: value,
                            value: value
                        }
                    });
                    locatesInMenu.push({
                        label: "<unmap>",
                        value: null
                    });
                    $locateInMenuCombo.autocomplete({
                        source: locatesInMenu,
                        minLength: 0,
                        select: function(event, ui) {
                            layout.selectedLocateInMenu(ui.item.value);
                        }
                    });
                    $locateInMenuCombo.on("mousedown", function() {
                        wasOpen = $locateInMenuCombo.autocomplete("widget").is(":visible");
                    })
                    .on("click", function() {
                        if(wasOpen) return;
                        $locateInMenuCombo.autocomplete("search", "");
                    });
                }
            };
            viewModel.selectedCommand.subscribe(function(newValue) {
                viewModel.isMappingChanged(
                    viewModel.commands[newValue] &&
                    viewModel.commands[newValue].isMappingChanged
                );
            });
        },
        _clear: function(commandID) {
            this._viewModel.selectedCommand(commandID);
            this._viewModel.commands = {};
            this._viewModel.isMappingChanged(false);
        },
        mapContainerToLayout: function(layoutName, containerID) {
            if(!this._layoutsDictionary[layoutName]) {
                this._layoutsDictionary[layoutName] = new Layout(layoutName, [containerID], this._viewModel);
            } else {
                this._layoutsDictionary[layoutName].containers.push(containerID);
            }
        },
        mapContainerToCommand: function(commandID, containerID) {
            var commands = this._viewModel.commands;
            commands[commandID] = commands[commandID] || new CommandMapping(this._layoutsDictionary);
            $.each(this._layoutsDictionary, function(layoutID, layout) {
                if(layout.containers.indexOf(containerID) > -1) {
                    commands[commandID].mapContainer(layoutID, containerID);
                }
            });
        },
        mapLocateInMenuToLayout: function(layoutName, containerID) {
            if(this._layoutsDictionary[layoutName]) {
                this._layoutsDictionary[layoutName].locatesInMenu.push(containerID);
            }
        },
        mapLocateInMenuToCommand: function(commandID, locateInMenuID) {
            var commands = this._viewModel.commands;
            commands[commandID] = commands[commandID] || new CommandMapping(this._layoutsDictionary);
            $.each(this._layoutsDictionary, function(layoutID, layout) {
                if(layout.locatesInMenu.indexOf(locateInMenuID) > -1) {
                    commands[commandID].mapLocateInMenu(layoutID, locateInMenuID);
                }
            });
        },
        getViewModel: function() {
            var _prevContainer = '';
            var arrayLayouts = $.map(this._layoutsDictionary, function(value, index) {
                value.group = _prevContainer != value.layoutID.split(' ')[0];
                _prevContainer = value.layoutID.split(' ')[0];
                return value;
            });
            this._viewModel.layouts(arrayLayouts);
            return this._viewModel;
        }
    });

})(DevExpress);