﻿/// <reference path="globalize.min.js" />
/// <reference path="jquery.js" />
(function(DX) {

    DX.designer.commands.addCommandHelper = addCommandHelper;
    DX.designer.commands.editCommandHelper = editCommandHelper;

    function addCommandHelper($dxView) {
        var commandsFromView = DX.designer.commands.Mapper.findCommandsInView($dxView);
        this.commandsFromView = commandsFromView;
        this.needToAppendCommand = function(commandID, containerID) {
            return commandID && commandsFromView.indexOf(commandID) === -1;
        }
    }
    $.extend(addCommandHelper.prototype, {
        checkSelectedCommandID: function(selectedCommandID) {
            if(this.commandsFromView.indexOf(selectedCommandID) > -1) {
                alert("Command with '" + selectedCommandID + "'already exists in the current view!");
                return false;
            }
            return true;
        },
        createNativeCommand: function(configText, selectedCommandID) {
            return {
                command: "addDxCommand",
                arguments: {
                    newConfig: configText,
                    nodeHTML: "<div data-bind=\"dxCommand: { title: '" + selectedCommandID + "', id: '" + selectedCommandID + "' }\"></div>"
                }
            }
        },
        autocompleteSource: function(commands) {
            var commandsIDs = Object.keys(commands),
                source = $.map(commandsIDs, function(value, index) {
                    return {
                        label: value,
                        value: value
                    }
                });
            source.push({
                label: "<New command>",
                value: ''
            });
            return source;
        },
        applyChanges: function(viewModel) {
            var selectedCommandID = viewModel.selectedCommand();
            this.commandsFromView.push(selectedCommandID);
            delete viewModel.commands[selectedCommandID];
            viewModel.selectedCommand("");
            $(".containers-combobox").text(null);
            $(".locate-in-menu-combobox").text(null);
        }
    });

    function editCommandHelper($dxView) {
        var commandsFromView = DX.designer.commands.Mapper.findCommandsInView($dxView);
        this.commandsFromView = commandsFromView;
        this.needToAppendCommand = function(commandID, containerID) {
            return commandID && commandsFromView.indexOf(commandID) > -1;
        }
    }
    $.extend(editCommandHelper.prototype, {
        checkSelectedCommandID: function(selectedCommandID) {
           return true;
        },
        createNativeCommand: function(configText, selectedCommandID) {
            return {
                command: "editDxCommand",
                arguments: {
                    newConfig: configText,
                    nodeHTML: undefined
                }
            }
        },
        autocompleteSource: function(commands) {
            return Object.keys(commands);
        },
        applyChanges: function(viewModel) {
            viewModel.applyMappingChanges();
        }
    });

})(DevExpress);