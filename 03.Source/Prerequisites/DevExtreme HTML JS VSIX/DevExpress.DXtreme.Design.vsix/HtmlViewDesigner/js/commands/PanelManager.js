﻿(function(DX) {
    function CommandsPanelManager(treesExplorer, bindingParser, isCommandMappingEnabled) {
        var onAddCommand = $.Callbacks(),
            onEditCommand = $.Callbacks(),
            $commandsPanel = treesExplorer.$commandsPanel(),
            $commandsList = $commandsPanel.find("#commands-list"),
            $editCommandButton;

        if(isCommandMappingEnabled) {
            $commandsPanel.find("#btn-cmd-add").show();
            $commandsPanel.find("#btn-cmd-add").off("click").on("click", function() {
                onAddCommand.fire({
                    $dxView: treesExplorer.$sourceTree()
                });
            });
        }

        function updateCommandsPanel() {
            var $elements = treesExplorer.$sourceTree().children().eq(0).children();
            $commandsList.children().remove();
            $elements.each(function(index, $element) {
                var parsedBinding = bindingParser.parse($element);
                if(parsedBinding && parsedBinding.widgetType === "dxCommand") {
                    var $command = $("<div />")
                        .addClass("command-item")
                        .text(JSON.parse(parsedBinding.data).title);

                    $commandsList.append($command);

                    $command.data("sourceNode", $element);
                    $($element).data("visualNode", $command);
                }
            });
            if($commandsList.children().length) {
                $commandsList.contents().filter(function() {
                    return this.nodeType === 3;
                }).remove();
            }
        }

        function refreshEditCommandButton($visualNode, nodeMetadata) {
            if(!isCommandMappingEnabled) {
                return;
            }
            if($editCommandButton && $editCommandButton.length > 0) {
                $editCommandButton.remove();
            }
            if(nodeMetadata && nodeMetadata.widgetType === "dxCommand") {
                var dataObject = JSON.parse(nodeMetadata.data),
                    commandID = dataObject.id && DX.designer.utils.trimBrackets(dataObject.id);
                $editCommandButton = $("<div id='btn-cmd-edit'>Edit</div>")
                    .appendTo($visualNode)
                    .on("click", function() {
                        onEditCommand.fire({
                            $dxView: treesExplorer.$sourceTree(),
                            commandID: commandID
                        });
                    });
            }
        }

        return {
            updatePanel: updateCommandsPanel,
            refreshEditCommandButton: refreshEditCommandButton,
            onAddCommand: onAddCommand,
            onEditCommand: onEditCommand
        }
    }

    DX.designer.CommandsPanelManager = CommandsPanelManager

})(DevExpress);