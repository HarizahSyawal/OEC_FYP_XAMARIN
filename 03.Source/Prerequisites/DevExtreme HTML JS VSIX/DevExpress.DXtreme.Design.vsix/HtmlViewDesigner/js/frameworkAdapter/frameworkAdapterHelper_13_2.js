﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["13.2"].frameworkAdapterHelper = frameworkAdapterHelper;

    function frameworkAdapterHelper(frameDevExpress, config) {
        this._init(frameDevExpress, config);
    }

    $.extend(frameworkAdapterHelper.prototype, DX.designer["13.1"].frameworkAdapterHelper.prototype, {
        _init: function(frameDevExpress, config) {
            this._DX = frameDevExpress;
            this.layoutName = config && (config.layoutSet || config.navigationType || config.defaultLayout);
            this._DX.framework.html.ViewEngine.prototype._checkMatchedTemplates = $.noop;
        },
        loadAvailablePlatforms: function(deviceOptions) {
            var availablePlatforms = this.getPlatforms();
            var newDeviceOptions = externalProcessCommand({ command: "availablePlatforms", data: JSON.stringify(availablePlatforms) });
            if(newDeviceOptions){
                $.extend(deviceOptions, JSON.parse(newDeviceOptions));
            }
        },
        getPlatforms: function() {
        	var availablePlatforms = {};
            $.each(this._DX.framework.html.layoutControllers, function(index, controllerInfo) {
                if(controllerInfo.platform) {
                    availablePlatforms[controllerInfo.platform] = ["phone", "tablet", "desktop"];
                }
            });
            return availablePlatforms;
        },
        getLayoutControllers: function(device) {
            var availableLayoutControllers = [],
                navigationType = this.layoutName,
                frameDX = this._DX;
            $.each(this._DX.framework.html.layoutControllers, function(index, controllerInfo) {
                var controller = controllerInfo.controller;
                if(frameDX.utils.findBestMatches($.extend({ navigationType: navigationType }, device), [controllerInfo]).length) {
                    availableLayoutControllers.push(controllerInfo);
                }
            });
            return availableLayoutControllers;
        },
        getHiddenBag: function($root, $viewPort) {
            return this._DX.framework.html.HtmlApplication.prototype._getHiddenBag($root, $viewPort);
        },
        getViewEngineOptions: function(device, $root) {
            return {
                $root: $root,
                device: device,
                defaultLayout: this.layoutName,
                templateEngine: new this._DX.framework.html.KnockoutJSTemplateEngine()
            };
        },
        applyDeviceTheme: function($viewPort) {
            $viewPort.removeClass();
            $viewPort.addClass("dx-viewport");
            this._DX.devices.attachCss($viewPort);
        },
        createCommandMapping: function(configCommandMapping, commandManagerOptions) {
            this._DX.framework.CommandMapping.prototype.checkCommandsExist = $.noop;
            commandManagerOptions.commandMapping = this._DX.framework.Application.prototype._createCommandMapping(
                configCommandMapping || {},
                commandManagerOptions.globalCommands || []);
        }
    });

})(DevExpress);