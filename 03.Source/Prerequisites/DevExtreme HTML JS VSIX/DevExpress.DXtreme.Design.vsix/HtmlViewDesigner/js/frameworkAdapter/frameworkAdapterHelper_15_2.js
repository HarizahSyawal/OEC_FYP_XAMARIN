﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-3.2.0.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["15.2"].frameworkAdapterHelper = frameworkAdapterHelper;

    var allPlatforms = ["ios", "android", "win", "generic"];

    function frameworkAdapterHelper(frameDevExpress, config) {
        this._init(frameDevExpress, config);
    }

    $.extend(frameworkAdapterHelper.prototype, DX.designer["15.1"].frameworkAdapterHelper.prototype, {
        allPlatforms: allPlatforms
    });

    function _getPlatforms(layoutSet) {
        return DevExpress.designer["14.1"].frameworkAdapterHelper._getPlatforms(layoutSet, allPlatforms);
    };

    frameworkAdapterHelper._getPlatforms = _getPlatforms;

})(DevExpress);