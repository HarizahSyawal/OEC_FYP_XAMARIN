﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["13.1"].frameworkAdapterHelper = frameworkAdapterHelper;

    var deviceTypes = ["phone", "tablet", "desktop"];

    function frameworkAdapterHelper(frameDevExpress, config) {
        this._DX = frameDevExpress;
        this.layoutName = config && config.defaultLayout;
    }

    $.extend(frameworkAdapterHelper.prototype, {
        loadAvailablePlatforms: function() {
        },
        getPlatforms: function() {
            return {
                "ios": deviceTypes,
                "android": deviceTypes,
                "generic": deviceTypes,
                "win8": deviceTypes
            };
        },
        getLayoutControllers: function(device) {
            return this._DX.framework.html.layoutControllers;
        },
        getHiddenBag: function() {
            return undefined;
        },
        getViewEngineOptions: function(device, $root, commandManagerOptions) {
            return {
                $root: $root,
                device: device,
                defaultLayout: this.layoutName,
                templateEngine: new this._DX.framework.html.KnockoutJSTemplateEngine(),
                commandManager: new this._DX.framework.html.CommandManager(commandManagerOptions)
            };
        },
        getNavigationManager: function() {
            return new this._DX.framework.NavigationManager();
        },
        ajaxImpl: function(args) {
            var deferred = $.Deferred(),
                content = loadFile(args.url);
            args.success(content);
            deferred.resolve(content);
            return deferred.promise();
        },
        applyDeviceTheme: function($viewPort, device) {
            var device = this._DX.devices.current();
            $viewPort.attr("class", getThemeClasses(device.platform, device.version && device.version[0]));
        },
        createCommandMapping: function() {
        }
    });

    function getThemeClasses(platform, version) {
        var platformToThemeMap = {
            "ios": "dx-theme-ios" + (version == 7 ? '7' : '') + " dx-theme-ios-typography",
            "android": "dx-theme-android dx-theme-android-typography",
            "desktop": "dx-theme-desktop dx-theme-desktop-typography",
            "win8": "dx-theme-win8 dx-theme-win8-typography"
        };
        return platformToThemeMap[platform];
    }

})(DevExpress);