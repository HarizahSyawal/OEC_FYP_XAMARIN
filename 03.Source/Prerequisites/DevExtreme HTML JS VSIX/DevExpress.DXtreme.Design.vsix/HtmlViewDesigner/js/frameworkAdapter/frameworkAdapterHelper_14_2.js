﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["14.2"].frameworkAdapterHelper = frameworkAdapterHelper;

    function frameworkAdapterHelper(frameDevExpress, config) {
        this._init(frameDevExpress, config);
    }

    $.extend(frameworkAdapterHelper.prototype, DX.designer["14.1"].frameworkAdapterHelper.prototype, {
        getHiddenBag: function($root, $viewPort) {
        },
        getViewEngineOptions: function(device, $root) {
            return {
                $root: $root,
                device: device
            };
        },
        applyDeviceTheme: function($viewPort) {
            $viewPort.removeClass();
            $viewPort.addClass("dx-viewport");
            this._DX.viewPort($viewPort);
        }
    });

})(DevExpress);