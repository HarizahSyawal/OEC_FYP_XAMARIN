﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-3.2.0.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["17.1"].frameworkAdapterHelper = frameworkAdapterHelper;

    function frameworkAdapterHelper(frameDevExpress, config) {
        this._init(frameDevExpress, config);
    }

    $.extend(frameworkAdapterHelper.prototype, DX.designer["15.2"].frameworkAdapterHelper.prototype, {

    });

    frameworkAdapterHelper._getPlatforms = DX.designer["15.2"].frameworkAdapterHelper._getPlatforms;

})(DevExpress);