﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {
    DevExpress.designer.frameworkAdapter = frameworkAdapter;

    function frameworkAdapter(options) {
        var frameDX = options.frameDX,
            config = options.config,
            $root = options.$root,
            $viewPort = options.$viewPort,
            bindingParser = options.bindingParser,
            urlsPatcher = options.urlsPatcher;

        frameDX.designMode = true;

        var frameworkVersion = frameworkVersion(frameDX);

        if(frameworkVersion === 13.1) {
            DX.designer.frameworkAdapterHelper = DX.designer["13.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["13.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["13.1"].widgets);
        } else if(frameworkVersion === 13.2) {
            DX.designer.frameworkAdapterHelper = DX.designer["13.2"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["13.2"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["13.2"].widgets);
        } else if(frameworkVersion === 14.1) {
            DX.designer.frameworkAdapterHelper = DX.designer["14.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["14.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["14.1"].widgets);
        } else if(frameworkVersion === 14.2) {
            DX.designer.frameworkAdapterHelper = DX.designer["14.2"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["14.2"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["14.2"].widgets);
        } else if(frameworkVersion === 15.1) {
            DX.designer.frameworkAdapterHelper = DX.designer["15.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["15.1"].widgets);
        } else if(frameworkVersion === 15.2) {
            DX.designer.frameworkAdapterHelper = DX.designer["15.2"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["15.2"].widgets);
        } else if(frameworkVersion === 16.1) {
            DX.designer.frameworkAdapterHelper = DX.designer["15.2"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["15.2"].widgets);
        } else if(frameworkVersion === 16.2) {
            DX.designer.frameworkAdapterHelper = DX.designer["15.2"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["15.2"].widgets);
        } else if(frameworkVersion === 17.1) {
            DX.designer.frameworkAdapterHelper = DX.designer["17.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["17.1"].widgets);
        } else if(frameworkVersion === 17.2) {
            DX.designer.frameworkAdapterHelper = DX.designer["17.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["17.2"].widgets);
        } else if(frameworkVersion === 18.1) {
            DX.designer.frameworkAdapterHelper = DX.designer["17.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["18.1"].widgets);
        } else if(frameworkVersion === 18.2) {
            DX.designer.frameworkAdapterHelper = DX.designer["17.1"].frameworkAdapterHelper;
            DX.designer.viewEngineAdapter = DX.designer["15.1"].viewEngineAdapter;
            DX.designer.metadata.registerWidgets(DX.designer["18.2"].widgets);
        } else {
            throw new Error("Unknown framework version " + frameworkVersion);
        }

        setTemplatePatching(bindingParser);

        var helper = new DX.designer.frameworkAdapterHelper(frameDX, config),
            commandManagerInfo = createCommandManager(config);

        function frameworkVersion(frameDX) {
            if(frameDX.VERSION) {
                var result = /^(\d\d\.\d)/.exec(frameDX.VERSION);
                if(result.length > 0) {
                    return parseFloat(result[0]);
                }
            }
            return frameDX.utils.findBestMatches ? 13.2 : 13.1;
        }

        function createCommandManager(config) {
            var commandManagerOptions = {
                globalCommands: []
            };
            var oldDxCommandCtor = frameDX.framework.dxCommand.prototype.ctor;
            frameDX.framework.dxCommand.prototype.ctor = function(element, options) {
                var src, opts = $.isPlainObject(element) ? element : options;
                if(opts && typeof (opts.iconSrc) == 'string') {
                    src = urlsPatcher.patchUrl(opts.iconSrc);
                    opts.iconSrc = src || opts.iconSrc;
                }
                oldDxCommandCtor.call(this, element, opts);
            };
            if(config) {
                if(config.navigation) {
                    config.navigation = $.grep(config.navigation, function (item, index) { return !!item; });
                    commandManagerOptions.globalCommands = $.map(config.navigation, function(item, index) {
                        var command = new frameDX.framework.dxCommand($.extend({
                            root: true,
                            id: item.id || "navigation_" + index,
                            location: "navigation"
                        }, item));
                        return command;
                    });
                };
                helper.createCommandMapping(config.commandMapping, commandManagerOptions);
                if(frameDX.framework.html.CommandManager) {
                    frameDX.framework.html.CommandManager.prototype._checkCommandId = $.noop;
                    commandManagerOptions.commandManager = new frameDX.framework.html.CommandManager({ commandMapping: commandManagerOptions.commandMapping });
                }
            }
            return {
                commandManagerOptions: commandManagerOptions,
                navigation: commandManagerOptions.globalCommands
            };
        }

        function initControllers(viewEngine) { //TODO: check framework version
            var availableLayoutControllers = helper.getLayoutControllers(viewEngine.device),
                hiddenBag = helper.getHiddenBag($root, $viewPort);
            $.each(availableLayoutControllers, function(index, controller) {
                if(controller.controller) {
                    controller = controller.controller;
                }
                if(controller.init) {
                    controller.init({
                        viewEngine: viewEngine,
                        $viewPort: $viewPort,
                        $hiddenBag: hiddenBag,
                        navigationManager: helper.getNavigationManager(),
                        commandManager: commandManagerInfo.commandManagerOptions.commandManager,
                        commandMapping: commandManagerInfo.commandManagerOptions.commandMapping,
                        navigation: commandManagerInfo.navigation
                    })
                }
                if(controller.renderNavigation) {
                    controller.renderNavigation(commandManagerInfo.navigation);
                }
            });
            return availableLayoutControllers;
        }

        function setTemplatePatching(bindingParser) {
            var provider = frameDX.framework.templateProvider;
            var oldApplyTemplate = provider.applyTemplate;
            var newApplyTemplate = function(element, model) {
                try {
                    bindingParser.patch(element, {});
                    return oldApplyTemplate(element, model);
                }
                catch(ex) {
                    throw {
                        internal: true,
                        message: "The current version of the dxView designer does not support the script version used in your project. To resolve the issue, upgrade your project using the <a href='http://js.devexpress.com/Documentation/Guide/Common/Migrate_to_the_New_Version/?version=17_1'>Project Converter</a> tool."
                    }
                }
            }
            DevExpress.designer.utils.redefinePopertyValue(provider, oldApplyTemplate, newApplyTemplate);
        }

        function createViewEngine(device, $root) {
            var newViewEngine = new frameDX.framework.html.ViewEngine(helper.getViewEngineOptions(device, $root, commandManagerInfo.commandManagerOptions));
            newViewEngine._ajaxImpl = helper.ajaxImpl;
            newViewEngine._extendModelFormViewTemplate = function($viewTemplate, model) {
                frameDX.utils.extendFromObject(model, $viewTemplate.data("dxView").option());
            };
            return newViewEngine;
        }

        function _setDevice(options) {
            var version = [];
            if(options.platform.indexOf("ios") == 0) {
                var _version = parseInt(options.platform.substring(3));
                version = [ !isNaN(_version) ? _version : 6 ];
                options.platform = "ios";
            } else if(options.platform.indexOf("android") == 0) {
                var _version = parseInt(options.platform.substring(7));
                version = [ !isNaN(_version) ? _version : 5 ];
                options.platform = "android";
            }
            frameDX.devices.current({
                platform: options.platform,
                version: version,
                deviceType: options.platform !== "desktop" ? options.deviceType : undefined
            });
            helper.applyDeviceTheme($viewPort);
            return $.extend(true, {}, frameDX.devices.current());
        }

        return {
            createViewEngineAdapter: function(callBack) {
                frameworkAdapter._clearRoot($root);
                var viewEngine = createViewEngine(frameDX.devices.current(), $root);
                viewEngine.init().done(function() {
                    var viewEngineAdapter = new DX.designer.viewEngineAdapter(viewEngine, initControllers(viewEngine), helper.layoutName, frameDX);
                    callBack(viewEngineAdapter);
                });
            },
            createViewEngine: function(device, $root) {
                var viewEngine = createViewEngine(device, $root);
                viewEngine._filterTemplatesByDevice = $.noop;
                viewEngine._loadExternalTemplates();
                return viewEngine;
            },
            setDevice: function(options) {
                var oldDevice = $.extend({}, frameDX.devices.current()),
                    newDevice = _setDevice(options);
                return (oldDevice.platform !== newDevice.platform ||
                    oldDevice.deviceType !== newDevice.deviceType ||
                    oldDevice.version && newDevice.version &&
                    oldDevice.version[0] !== newDevice.version[0]);
            },
            loadToolboxItems: function() {
                externalProcessCommand({
                    command: "toolboxItems",
                    data: JSON.stringify({
                        toolboxItems: DevExpress.designer.metadata.getToolboxItems(),
                        frameworkVersion: frameworkVersion
                    })
                });
            },
            loadAvailablePlatforms: function(deviceOptions) {
                return helper.loadAvailablePlatforms(deviceOptions);
            },
            getPlatforms: function() {
                return helper.getPlatforms();
            },
            defaultMapping: function() {
                return frameDX.framework.CommandMapping.defaultMapping;
            },
            isCommandMappingEnabled: function() {
                return frameworkVersion > 13.2;
            }
        }
    }

    frameworkAdapter._clearRoot = function($root) {
        $root.find("[data-options^=dxLayout],[data-options^=dxView]").remove();
        $root.find("#visualTree-content").html('');
        //$root.html("<div id='visualTree-content' style='height: 100%'></div>");  TODO: check if can replace 2 previous lines
    }

})(DevExpress);