﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["14.1"].frameworkAdapterHelper = frameworkAdapterHelper;

    var utils = DX.designer.utils,
        allPlatforms = ["ios", "android", "win8", "generic"];

    function frameworkAdapterHelper(frameDevExpress, config) {
        this._init(frameDevExpress, config);
    }

    $.extend(frameworkAdapterHelper.prototype, DX.designer["13.2"].frameworkAdapterHelper.prototype, {
        getPlatforms: function() {
            return _getPlatforms(this._DX.framework.html.layoutSets[this.layoutName]);
        },
        getLayoutControllers: function(device) {
            var availableLayoutControllers = [],
                frameDX = this._DX;
            $.each(this._DX.framework.html.layoutSets[this.layoutName], function(index, controllerInfo) {
                var controller = controllerInfo.controller;
                if(frameDX.utils.findBestMatches(device, [controllerInfo]).length) {
                    availableLayoutControllers.push(controllerInfo);
                }
            });
            return availableLayoutControllers;
        },
        getViewEngineOptions: function(device, $root) {
            return {
                $root: $root,
                device: device,
                templateEngine: new this._DX.framework.html.KnockoutJSTemplateEngine()
            };
        },
        getNavigationManager: function() {
            return new this._DX.framework.StackBasedNavigationManager();
        },
        ajaxImpl: function(args) {
            var deferred = $.Deferred();
            deferred.resolve(loadFile(args.url));
            return deferred.promise();
        },
        applyDeviceTheme: function($viewPort) {
            $viewPort.removeClass();
            $viewPort.addClass("dx-viewport");
            this._DX.ui.themes.attachCssClasses($viewPort);
            this._DX.devices.attachCssClasses($viewPort);
        },
        createCommandMapping: function(configCommandMapping, commandManagerOptions) {
            var appPrototype = this._DX.framework.Application.prototype;
            this._DX.framework.CommandMapping.prototype.checkCommandsExist = $.noop;
            commandManagerOptions.commandMapping = appPrototype._createCommandMapping(configCommandMapping || {});
            appPrototype._createNavigationCommands(commandManagerOptions.globalCommands);
            appPrototype._mapNavigationCommands(commandManagerOptions.globalCommands, commandManagerOptions.commandMapping);
        }
    });

    function _getPlatforms(layoutSet, platforms) {
        platforms = platforms || allPlatforms;

        if(layoutSet === undefined)
            throw Error("The LayoutSet is undefined. Please check the layout references in the index.html file and layout name in the application config file (appname.config.js).");

        var availablePlatforms = {};
        $.each(layoutSet, function(index, controllerInfo) {
            if(controllerInfo.modal)
                return;
            var supportedDevices = getSupportedDevices(controllerInfo),
                platform = controllerInfo.platform;
            if(platform) {
                availablePlatforms[platform] = utils.extendArray(availablePlatforms[platform], supportedDevices);
            } else {
                platforms.forEach(function(value) {
                    availablePlatforms[value] = utils.extendArray(availablePlatforms[value], supportedDevices);
                });
            }
        });
        return availablePlatforms;
    }

    function getSupportedDevices(controllerInfo) {
        var devices = [];
        if(controllerInfo.phone === true) {
            devices.push("phone");
        } else if(controllerInfo.tablet === true) {
            devices.push("tablet");
        } else if(controllerInfo.desktop === true) {
            devices.push("desktop");
        } else {
            if(controllerInfo.phone !== false) {
                devices.push("phone");
            }
            if(controllerInfo.tablet !== false) {
                devices.push("tablet");
            }
            if(controllerInfo.desktop !== false) {
                devices.push("desktop");
            }
        }
        return devices;
    }
    frameworkAdapterHelper._getPlatforms = _getPlatforms;

})(DevExpress);