﻿(function(DX) {
    DX.designer.createDropPositionEvaluator = PositionEvaluator;

    var dropPositions = {
        before: 'before',
        after: 'after',
        inside: 'inside',
        join: 'join'
    }
    DX.designer.DropPositions = dropPositions;
    
    function PositionEvaluator(treesExplorer, metadata, scaleProvider) {

        function getClosestChildNodeForTargetPoint($containder, point) {
            return getClosestNode($containder.children(), point);
        }

        function getClosestNode($nodes, point) {
            var Xdelta = Number.POSITIVE_INFINITY,
                Ydelta = Number.POSITIVE_INFINITY,
                $closestNode = null;

            $nodes.each(function (index, item) {
                var $item = treesExplorer.visualNode($(item));
                if ($.isExist($item) && self._isNodeVisible($item)) {
                    var deltas = getDistancesBetweenNodeAndPoint($item, point);
                    if (isPointInsideNode(deltas)) {
                        $closestNode = $(item);
                        return false;
                    }
                    var x = Math.min(Math.abs(deltas.left), Math.abs(deltas.right)),
                        y = Math.min(Math.abs(deltas.bottom), Math.abs(deltas.top));

                    if (y < Ydelta || Math.abs(y - Ydelta) <= 2 && x <= Xdelta) {
                        $closestNode = $(item);
                        Ydelta = y;
                        Xdelta = x;
                    }
                }
            });
            return $closestNode;
        }
        
        function visibleSibling($node, needGetNext) {
            var $test = $node,
                $testVisual;
            do {
                $test = needGetNext ? $test.next() : $test.prev();
                $testVisual = treesExplorer.visualNode($test);
            } while($.isExist($testVisual) && !self._isNodeVisible($testVisual));
            return $test;
        }
        
        function getSourceNodeBoundaries($sourceNode) {
            var $visualNode = treesExplorer.visualNode($sourceNode);
            if($visualNode.length) {
                return scaleProvider.nodeBoundsInMainWindow($visualNode);
            }
        }
        function isNodesOnSameLine(nodeBoundaries1, nodeBoundaries2) {
            return (nodeBoundaries1.y2 - nodeBoundaries2.y1 >= 1) && (nodeBoundaries2.y2 - nodeBoundaries1.y1 >= 1)
        }
        function coordinatesCenter(x1, x2) {
            return (x1 + x2) / 2;
        }
        function isPointInsideNode(deltas) {
            return deltas.left > 0 && deltas.right > 0 && deltas.top > 0 && deltas.bottom > 0;
        }
        function getDropInsertPosition($node, isContainer, point) {
            var deltas = getDistancesBetweenNodeAndPoint($node, point);
            if(isContainer && isPointInsideNode(deltas)) {
                return dropPositions.inside;
            }
            var nodeBoundaries = scaleProvider.nodeBoundsInMainWindow($node),
                t = (point.y - nodeBoundaries.y2) + (nodeBoundaries.height / nodeBoundaries.width) * (point.x - nodeBoundaries.x1);
            return t < 0  ? dropPositions.before : dropPositions.after;
        }
        function getDistancesBetweenNodeAndPoint($node, point) {
            var nodeBoundaries = scaleProvider.nodeBoundsInMainWindow($node);
            return {
                left: point.x - nodeBoundaries.x1,
                right: nodeBoundaries.x2 - point.x,
                top: point.y - nodeBoundaries.y1,
                bottom: nodeBoundaries.y2 - point.y
            }
        }
        
        var self = {
            getNodeInsertInfo: function($pointOwner, targetPoint, insertObjectMetadata) {
                var $sourceTarget = treesExplorer.closestSourceNode($pointOwner);
                if(!$.isExist($sourceTarget) || $.containsOrSame($sourceTarget[0], treesExplorer.dxView().get(0))) {
                    if (treesExplorer.dxContentElements().length > 0) {
                        $sourceTarget = getClosestNode(treesExplorer.dxContentElements(), targetPoint);
                    }
                    else {
                        $sourceTarget = treesExplorer.dxView();
                    }
                }

                var $child = getClosestChildNodeForTargetPoint($sourceTarget, targetPoint);
                if(insertObjectMetadata && insertObjectMetadata.getTargetElement) {
                    var $container = insertObjectMetadata.getTargetElement($sourceTarget);
                    if($.isExist($container)) {
                        $child = getClosestChildNodeForTargetPoint($container, targetPoint);
                        if(!$.isExist($child)) {
                            return {
                                position: dropPositions.inside,
                                $targetNode: $container
                            }
                        }
                    }
                }

                if(insertObjectMetadata && insertObjectMetadata.isJoinable) {
                    return {
                        position: dropPositions.join,
                        $targetNode: insertObjectMetadata.isAvailableJoinData($sourceTarget) ? $sourceTarget : null
                    }
                }

                var isContainer;
                if($.isExist($child)){
                    $sourceTarget = $child;
                    isContainer = false;
                }
                else {
                    isContainer = metadata.isContainer($sourceTarget);
                }

                return {
                    position: getDropInsertPosition(treesExplorer.visualNode($sourceTarget), isContainer, targetPoint),
                    $targetNode: $sourceTarget
                }
            },

            getDropInsertCoordinates: function(dropInfo) {
                var target = getSourceNodeBoundaries(dropInfo.$targetNode),
                    parent = getSourceNodeBoundaries(dropInfo.$targetNode.parent()),
                    result = { left : target.x1, top : target.y1};

                switch(dropInfo.position) {
                    case DX.designer.DropPositions.before:
                        var prev = getSourceNodeBoundaries(visibleSibling(dropInfo.$targetNode, false));
                        if(prev && isNodesOnSameLine(target, prev)) {
                            result.left = coordinatesCenter(target.x1, prev.x2);
                        }
                        else {
                            result.left = coordinatesCenter(target.x1, parent.x1);
                        }
                        break;
                    case DX.designer.DropPositions.after:
                        var next = getSourceNodeBoundaries(visibleSibling(dropInfo.$targetNode, true));
                        if(next && isNodesOnSameLine(target, next)) {
                            result.left = coordinatesCenter(target.x2, next.x1) - 1;
                        }
                        else {
                            result.left = coordinatesCenter(target.x2, parent.x2) - 1;
                            if(result.left - target.x2 > 5) {
                                result.left = target.x2 + 5;
                            }
                        }
                        break;
                    case DX.designer.DropPositions.inside:
                        result.left = coordinatesCenter(target.x1, target.x2) - 1;
                        break;
                }
                return result;
            },

            _isNodeVisible: function($node) {
                return $node.is(":visible");
            }
        };
        return self;
    }
})(DevExpress);