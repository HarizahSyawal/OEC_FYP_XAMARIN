﻿
function ShowErrorMessage(caption, message) {
    var $div;
    if(!message) { return; }
    $(document.body).children(':not(#trial-pannel)').first().hide();
    $div = $('#error-info').length
        ? $('#error-info')
        : $('<div id="error-info"/>')
            .css({
                top: '50%',
                left: '0',
                position: 'fixed',

                width: '100%',

                padding: '5px 0',

                color: '#444',
                textAlign: 'center'
            })
            .html('<p><strong>' + caption + '</strong><br>Message:&nbsp;<i>' + message + '</i></p>')
            .appendTo(document.body);
    $div.show();
}
function handleException(ex) {
    if(ex) {
        if(ex.internal) {
            ShowErrorMessage("Warning", ex.message || ex.description);
            $('#error-info a').click(function () {
                externalProcessCommand({ command: "executeExternalUrl", data: $(this).attr('href') });
            });
        }
        else
            ShowErrorMessage("Error occurred", ex.message || ex.description);
    }
}

function wrapWithTryCatch(fn, options) {
    options = $.extend({
        context: window,
        catchCallback: $.noop,
        finallyCallback: $.noop
    }, options);
    return function() {
        try {
            $('#error-info').length && $('#error-info').remove();
            $(document.body).children(':not(#trial-pannel)').first().show();

            return fn.apply(options.context, [].slice.call(arguments));
        } catch(ex) {
            options.catchCallback(ex);
            handleException(ex);
        } finally {
            options.finallyCallback();
        }
    };
}
