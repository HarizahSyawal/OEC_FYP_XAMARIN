﻿(function(DX) {
    function redefinePopertyValue(object, oldValue, newValue) {
        var isValueFound = false;
        for(var id in object) {
            if(object[id] === oldValue) {
                object[id] = newValue;
                isValueFound = true;
            }
        }
        if(!isValueFound) {
            throw new Error("The target property is not found.");
        }
    }

    function isBrowserLessThanIE9() {
        //JQuery.support.leadingWhitespace is available in 1.xx versions only, since jquery 2.0 IE8 is not supported
        return $().jquery.substring(0, 2) === "1." && !$.support.leadingWhitespace;
    }

    function removeBracketsFromID(id) {
        if((id[0] === "'" || id[0] === '"') && id[0] === id[id.length - 1]) {
            return id.replace(/^('|")|('|")$/g, '');
        }
    }

    function removeBracketsFromID(id) {
        if((id[0] === "'" || id[0] === '"') && id[0] === id[id.length - 1]) {
            return id.replace(/^('|")|('|")$/g, '');
        }
    }

    function trimBrackets(id) {
        return id.replace(/^('|")|('|")$/g, '');
    }

    function stringifyFormat(obj, level) {
        var type = typeof (obj),
            level = level || 0,
            spaces = '\r\n';
        var i = level;
        while(i--) {
            spaces += '\t';
        }
        if(type !== "object" || obj === null) {
            return obj;
        } else {
            var key,
                value,
                json = [],
                isArray = (obj && obj.constructor == Array);
            for(key in obj) {
                value = obj[key];
                type = typeof (value);
                if(type === "object" && value !== null) {
                    value = stringifyFormat(value, level + 1);
                } else if(type === "string") {
                    value = '"' + value + '"';
                }
                json.push((isArray ? "" : '"' + key + '": ') + String((value == null || value == undefined ? '' : value)));
            }
            return (isArray ? "[" : "{") + spaces + '\t' + json.join(',' + spaces + '\t') + spaces + (isArray ? "]" : "}");
        }
    }

    function isString(value) {
        return value && typeof (value) === "string";
    }

    function capitaliseFirstLetter(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function pushUnique(array, value) {
        if(array.indexOf(value) === -1) {
            array.push(value);
        }
    }

    function extendArray(array1, array2) {
        array1 = array1 || [];
        array2.forEach(function(value) {
            pushUnique(array1, value);
        });
        return array1;
    }

    DX.designer.utils = {
        redefinePopertyValue: redefinePopertyValue,
        isBrowserLessThanIE9: isBrowserLessThanIE9,
        trimBrackets: trimBrackets,
        stringifyFormat: stringifyFormat,
        isString: isString,
        capitaliseFirstLetter: capitaliseFirstLetter,
        pushUnique: pushUnique,
        extendArray: extendArray
    }

})(DevExpress);