/// <reference path="jquery.js" />
(function(DX) {

    var BindingParser = (function() {

        function tagNameLower(element) {			
            return element && element.tagName && element.tagName.toLowerCase();
        }

        function parseObject(stringData) {
            return ko.jsonExpressionRewriting.parseObjectLiteral(stringData);
        }

        function objectLiteralToJSON(stringBinding) {
            var parsedValues = parseObject(stringBinding),
                resultObject = {};
            $.each(parsedValues, function (index, item) {
                if (item.key) {
                    resultObject[$.trim(item.key)] = $.trim(item.value);
                }
            });
            return JSON.stringify(resultObject);
        }

        function arrayToJSON(stringBinding) {
            var resultObject = DX.designer.json_parseArray(stringBinding)
            return JSON.stringify(resultObject);
        }

        function knockoutBindingToObject(bindingString, model, processBindingProperty) {
            var bindingContext = [model || {}],
                isTemplate = false;

            bindingString = $.trim(bindingString);
            if(bindingString.charAt(0) !== '{' || bindingString.charAt(bindingString.length - 1) !== '}') {
                bindingString = "{" + bindingString + "}";
            }
            var patchedData = DX.designer.json_parse(bindingString, function(key, value) {
                if(value && typeof value === 'object') {
                    if(key.toLowerCase() === "dxscrollview") {
                        value["showScrollbar"] = "onHover";
                        value["scrollByThumb"] = true;
                        value["useSimulatedScrollbar"] = false;
                    }
                    else if(key.toLowerCase() === "dxlist") {
                        value["showScrollbar"] = value["useNativeScrolling"] ? false : "onHover";
                    } else if(key.toLowerCase() === "dxcalendar") {
                        delete value["value"];
                    }
                    return value;
                }
                isTemplate = key === "foreach";
                try {
                    key = $.trim(key);
                    if(typeof processBindingProperty === 'function') {
                        value = processBindingProperty(key, value);
                    }
                    var expressionFn = getEvaluationFunction(key + ":" + value, bindingContext.length);
                    var val = expressionFn(bindingContext)[key];

                    // T208911, T513180
                    if(val instanceof jQuery) {
                        try {
                            JSON.stringify(val);
                        }
                        catch(ex) {
                            val = null;
                        }
                    }

                    if(val !== window[$.trim(value)]) {
                        return val;
                    }
                } catch(ex) {
                    if(isTemplate) {
                        return [];
                    } else if(key.toLowerCase() === 'text' || key.toLowerCase() === 'title') {
                        return 'Undefined';
                    } else if(DX.designer.metadata.getTypesOfWidgets().indexOf(key) != -1) {
                        return {};
                    }
                }
            });
            return {
                patchedObject: patchedData,
                isTemplate: isTemplate
            }
        }

        BindingParser.knockoutBindingToJSON = function(stringBinding) {
            if(stringBinding.charAt(0) === "[") {
                return arrayToJSON(stringBinding);
            }
            return objectLiteralToJSON(stringBinding);
        }
        BindingParser.knockoutBindingToObject = knockoutBindingToObject;
        BindingParser.isKnockoutBindingValid = function (stringBinding) {
            try {
                DX.designer.json_parse(stringBinding, function (key, value) { });
            }
            catch (ex) {
                return false;
            }
            return true;
        }

        function getEvaluationFunction(bindingsString, scopesCount) {
            var buildEvalWithinScopeFunction = function (expression, scopeLevels) {
                // Build the source for a function that evaluates "expression"
                // For each scope variable, add an extra level of "with" nesting
                // Example result: with(sc[1]) { with(sc[0]) { return (expression) } }
                var functionBody = "return (" + expression + ")";
                for(var i = 0; i < scopeLevels; i++) {
                    functionBody = "with(sc[" + i + "]) { " + functionBody + " } ";
                }
                return new Function("sc", functionBody);
            }

            var rewrittenBindings = " { " + bindingsString + " } ";
            return buildEvalWithinScopeFunction(rewrittenBindings, scopesCount);
        };

        function BindingParser(typesOfWidgets, urlsPatcher) {
            this._knownBindings = [];
            this._initKnownBindings(typesOfWidgets);
            this._bindingProvider = ko.bindingProvider.prototype;
            this._urlsPatcher = urlsPatcher;
        }
        BindingParser.prototype._initKnownBindings = function (typesOfWidgets) {
            var self = this;
            self._knownBindings = typesOfWidgets;
        };

        BindingParser.prototype.patch = function(element, model, processBindingProperty) {
            var domElement = element instanceof jQuery ? element.get(0) : element;
            this._urlsPatcher.patchUrls($(domElement));
            this._patchDomElement(domElement, model, processBindingProperty);
        }

        BindingParser.prototype._patchDomElement = function (domElement, model, processBindingProperty) {
            if(checkElementTagName(domElement, ["iframe"])) return;

            if(checkElementTagName(domElement, ["script", "textarea"])) {
                var koDomElement = new ko.templateSources.domElement(domElement),
                    contents = ko.utils.parseHtmlFragment(koDomElement.text());

                this._patchElementsArray(contents, model, processBindingProperty);
                var $templateContent = $("<div>").append(contents);
                this._urlsPatcher.patchUrls($templateContent);

                koDomElement.text($templateContent.html());
            } else {
                this._patchElementsArray($(domElement).contents().toArray(), model, processBindingProperty);
            }
        };

        BindingParser.prototype._patchElementsArray = function(elementsArray, model, processBindingProperty) {
            var self = this;
            $.each(elementsArray,
                function(index, el) {
                    if(!($(el).attr("data-dx-role") === "template" || $(el).is(':dxElement(dxTemplate)'))) {
                        var result = self.patchElement(el, model, processBindingProperty);
                        if(!result || !result.isTemplate) {
                            self._patchDomElement(el, model, processBindingProperty);
                        }
                    }
                });
        };

        function checkElementTagName(domElement, tagNames) {
            return tagNames.indexOf(tagNameLower(domElement)) > -1;
        }

        BindingParser.prototype.patchElement = function(el, model, processBindingProperty) {
            var self = this,
                bindingString = self._bindingProvider.getBindingsString(el);

            if(bindingString) {
                var result = self._patch(bindingString, model, processBindingProperty);
                if(el.nodeType === 8) {
                    // if comment
                    el.data = "ko " + result.bindings;
                    //el.text = "<!-- ko " + result.bindings + " -->"
                } else {
                    $(el).attr("data-bind", result.bindings);
                }
                return result;
            } else {
                return null;
            }
        };
        BindingParser.prototype._patch = function(bindingString, model, processBindingProperty) {
            var result = knockoutBindingToObject(bindingString, model, processBindingProperty);
            return {
                bindings: JSON.stringify(result.patchedObject).slice(1).slice(0, -1),
                isTemplate: result.isTemplate
            };
        };
        BindingParser.prototype.parse = function (element, attrToParse) {
            var self = this;
            element = $(element);
            return self._parse(element.attr(attrToParse || "data-bind"));
        };
        BindingParser.prototype._parse = function (data) {
            var self = this;
            var result = {
                widgetType: null,
                data: {},
                otherBindings: ''
            };
            $.each(parseObject(data), function (i, item) {
                var index = $.inArray($.trim(item.key.replace(/"/g, "")), self._knownBindings);
                if(index !== -1) {
                    if(result.widgetType) {
                        result.additionalWidgetType = self._knownBindings[index];
                        result.additionalData = objectLiteralToJSON(item.value);
                    } else {
                        result.widgetType = self._knownBindings[index];
                        result.data = objectLiteralToJSON(item.value);
                    }
                } else {
                    result.otherBindings += item.key + ":" + item.value;
                }
            });

            if(result.widgetType) {
                return result;
            }
        };

        BindingParser.prototype.stringify = function (widgetType, data) {
            return DX.designer.metadata.byType(widgetType).stringify(data);
        };
        return BindingParser;
    })();
    DX.designer.BindingParser = BindingParser;

})(DevExpress);
