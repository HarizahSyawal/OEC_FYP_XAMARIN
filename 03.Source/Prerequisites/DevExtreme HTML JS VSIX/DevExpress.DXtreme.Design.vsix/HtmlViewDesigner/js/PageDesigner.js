﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX, undefined) {
    DX.designer.createViewDesigner = ViewDesigner;
    var SELECTED_NODE_CLASS = "selected";
    function ViewDesigner(viewSource, viewEngineAdapter, bindingParser, urlsPatcher, isCommandMappingEnabled) {
        var treesExplorer = DX.designer.createTreesExplorer(SELECTED_NODE_CLASS),
            $surface = treesExplorer.$visualTree(),
            $sourceTree = treesExplorer.$sourceTree(),
            dragDropEvents = DX.designer.DragDropEvents(),
            scaleProvider = DX.designer.scaleProvider(DX.designer.simulator, $("iframe")),
            selectionTitle = SelectionTitleManager($("#selection-title"), scaleProvider),
            dragDropManager = DX.designer.DragDropManager(selectionTitle, treesExplorer, DX.designer.metadata, scaleProvider),
            commandsPanel = DX.designer.CommandsPanelManager(treesExplorer, bindingParser, isCommandMappingEnabled),
            viewRenderer = new DevExpress.designer.viewRenderer(viewEngineAdapter, urlsPatcher, bindingParser),
            walker;

        function removeNode($node) {
            if (treesExplorer.isDxView($node[0]) || $node[0] === treesExplorer.dxContentElements()[0]) {
                return false;
            }

            var removeNodeIndex = treesExplorer.sourceNodeIndex($node),
                selectedNodeIndex = treesExplorer.sourceNodeIndex(walker.toParent($node));
            executeCommand('RemoveNode', { nodeIndex: removeNodeIndex }, selectedNodeIndex);
            return true;
        }

        function updateSelectedNode(command) {
            var $selected = treesExplorer.selectedSourceNode();
            if(!$selected.length) {
                return false;
            }
            
            //var updatedAttr = DX.designer.metadata.setCommandData($selected, command);
            var updatedAttr;
            var updatedContent;
            var result = DX.designer.metadata.setCommandData($selected, command);
            if(result === null) {
                return false;
            }

            if(typeof result === "string") {
                updatedAttr = result;
            }
            else if(typeof result === "object") {
                updatedAttr = result.updatedAttr;
                updatedContent = result.updatedContent;
            }

            var selectedNodeIndex = treesExplorer.sourceNodeIndex($selected),
                cmdArgs = {
                    nodeIndex: selectedNodeIndex,
                    attributeName: updatedAttr,
                    attributeValue: updatedAttr === "innerText" ? $.trim($selected.text()) : $selected.attr(updatedAttr)
                };
            if(updatedContent) {
                cmdArgs.attributeContent = updatedContent;
            }

            executeCommand('UpdateNode', cmdArgs, selectedNodeIndex);
            return true;
        }

        function setSelectedSourceNode($node, applyNodePosition) {
            $node = $node instanceof jQuery ? $node : $($node);
            if(!$node.length) {
                return false;
            }
            
            var $current = treesExplorer.selectedSourceNode(),
                $visualNode = treesExplorer.closestVisualNode($node);
            if($visualNode.length) {
                $node = treesExplorer.sourceNode($visualNode);
            }
            if($node.get(0) === $current.get(0)) {
                return false;
            }
            
            treesExplorer.visualNode($current).removeClass(SELECTED_NODE_CLASS);
            $visualNode.addClass(SELECTED_NODE_CLASS);

            var data = DX.designer.metadata.getCommandData($node);
            commandsPanel.refreshEditCommandButton($visualNode, data);
            RefreshSelectedNodeStyle($visualNode);
            selectionTitle.showTitle($node, $visualNode, DX.designer.metadata.byNode($node));

            var commandInfo = {
                'command': 'selected',
                selectedNodeIndex: applyNodePosition ? treesExplorer.sourceNodeIndex($node) : -1
            };
            externalProcessCommand($.extend(
                commandInfo,
                data
            ));
            return true;
        }

        function changeSelectedNode(direction) {
            var $from = treesExplorer.selectedSourceNode() || treesExplorer.sourceNode(this),
                $next = walker.go($from, direction);
            while(!$.isExist(treesExplorer.visualNode($next)) && $from.get(0) !== $next.get(0)) {
                $from = $next;
                $next = walker.go($from, direction);
            }
            setSelectedSourceNode($next, true);
        }

        function RefreshSelectedNodeStyle($selected) {
            if(!$selected || !$selected.length) return;

            var styleSheet = getStyleSheet("selectedElementStyle"),
                newStyle = GetSelectedNodeStyle($selected.parent());
            if(styleSheet) {
                var newRule = 'outline: 1px dashed ' + newStyle.borderColor + ' !important;' +
                               'color: #808080 !important;';
                if(styleSheet.cssRules.length) {
                    styleSheet.removeRule(0);
                }
                styleSheet.addRule('.' + SELECTED_NODE_CLASS, newRule, 0);
            }
        }
        function GetSelectedNodeStyle($selected) {
            var $checkObject = $selected,
                backgroundColor,
                rgbColorFormat = /^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/,
                rgbColorHexFormat = /^#([a-fA-F0-9]{3,6})$/,
                backgroundToBorderMap = {
                    "black": "white",
                    "white": "black"
                };


            do {
                backgroundColor = $checkObject.css('background-color');
                $checkObject = $checkObject.parent();
                if(backgroundToBorderMap[backgroundColor]) {
                    return { "borderColor": backgroundToBorderMap[backgroundColor] };
                }
                if(backgroundColor && backgroundColor.search(rgbColorFormat) === -1 && backgroundColor.search(rgbColorHexFormat) === -1) {
                    backgroundColor = undefined;
                }
            } while($checkObject.length && !backgroundColor);

            if(backgroundColor) {
                var rgbComponents = [];
                if(backgroundColor.search(rgbColorFormat) > -1) {
                    var parts = backgroundColor.split(rgbColorFormat);
                    rgbComponents[0] = parts[1];
                    rgbComponents[1] = parts[2];
                    rgbComponents[2] = parts[3];
                }
                else {
                    if(backgroundColor.length === 7) {
                        rgbComponents[0] = '0x' + backgroundColor.charAt(1) + backgroundColor.charAt(2);
                        rgbComponents[1] = '0x' + backgroundColor.charAt(3) + backgroundColor.charAt(4);
                        rgbComponents[2] = '0x' + backgroundColor.charAt(5) + backgroundColor.charAt(6);
                    }
                    else {
                        rgbComponents[0] = '0x' + backgroundColor.charAt(1) + backgroundColor.charAt(1);
                        rgbComponents[1] = '0x' + backgroundColor.charAt(2) + backgroundColor.charAt(2);
                        rgbComponents[2] = '0x' + backgroundColor.charAt(3) + backgroundColor.charAt(3);
                    }
                }

                var newBorderColor = Number(rgbComponents[0]) < 128 && Number(rgbComponents[1]) < 128 && Number(rgbComponents[2]) < 128 ? "white" : "black";
                return { "borderColor": newBorderColor };
            }
        }
        function getStyleSheet(title) {
            for(var i = 0; i < DevExpress.designer.frameWindow.document.styleSheets.length; i++) {
                var sheet = DevExpress.designer.frameWindow.document.styleSheets[i];
                if (sheet.title == title) {
                    return sheet;
                }
            }
        }

        /*#endregion*/

        function nodeClickHandler(event) {
            $.originalEvent(event).preventDefault();
            $.originalEvent(event).stopPropagation();
            setSelectedSourceNode(treesExplorer.closestSourceNode($.originalEvent(event).srcElement), true);
        }
        
        function getViewSource() {
            return $sourceTree.html();
        }

        function onDropHandler(args) {
            var dropInfo = dragDropManager.getDropPositionInfo(args);
            tryDrop(dropInfo.$targetNode, args.dragSource, dropInfo.position, dropInfo.$draggedNode);
        }
        function tryDrop($target, dragSource, dropPosition, $draggedNode) {
            var targetNodeIndex = treesExplorer.sourceNodeIndex($target),
                draggedNodeIndex = $.isExist($draggedNode) ? treesExplorer.sourceNodeIndex($draggedNode) : -1;
            if (targetNodeIndex === draggedNodeIndex) {
                return;
            }

            var $addedNode = dragDropManager.drop({ $targetNode: $target, position: dropPosition }, dragSource);
            if ($.isExist($addedNode)) {
                //selectedSourceNodeIndex = treesExplorer.sourceNodeIndex($addedNode);
                var cmdArgs = {
                    targetNodeIndex: targetNodeIndex,
                    nodeHTML: dragSource,
                    insertDirection: dropPosition,
                    draggedNodeIndex: draggedNodeIndex
                };
                executeCommand('DropNode', cmdArgs, treesExplorer.sourceNodeIndex($addedNode));
            }
        }
        function onDragOverHandler(args) {
            dragDropManager.dragOver(args);
        }

        function executeCommand(cmdName, arguments, selectedNodeIndex) {
            var resultHTML = externalProcessCommand({
                command: cmdName,
                arguments: arguments
            });
            setNewViewSource(resultHTML);
            setSelectedSourceNode(treesExplorer.sourceNodeByIndex(selectedNodeIndex), true);
        }

        function _synchronize() {
            if($sourceTree.length === 0) return;

            var selectedSourceNodeIndex = treesExplorer.sourceNodeIndex(treesExplorer.selectedSourceNode());
            refreshVisualTree();
            if(selectedSourceNodeIndex > -1) {
                treesExplorer.visualNodeBySourceIndex(selectedSourceNodeIndex).addClass(SELECTED_NODE_CLASS);
            }
            selectionTitle.refreshPosition(treesExplorer.selectedVisualNode());
        }

        var synchronize = wrapWithTryCatch(_synchronize);

        var setNewViewSource = wrapWithTryCatch(function(viewSource) {
            if($sourceTree.length === 0 || !viewSource) return;

            $sourceTree.html(viewSource);
            refreshVisualTree();
            selectionTitle.hideTitle();
            $surface.removeClass(SELECTED_NODE_CLASS);
        });

        function refreshVisualTree() {
            viewRenderer.refreshVisualView($sourceTree, $surface);
            commandsPanel.updatePanel();
            treesExplorer.refresh();
            walker = DX.designer.createWalker(treesExplorer.dxView());
            dragDropManager.initViewRootNodeForDrag();
        }

        function setSelectedNode(nodeIndex) {
            setSelectedSourceNode($sourceTree.find('*').eq(nodeIndex));
        }

        var deviceOptionsChanged = wrapWithTryCatch(function(needSynchronize, newViewEngineAdapter) {
            if(needSynchronize) {
                viewRenderer.setViewEngineAdapter(newViewEngineAdapter);
                _synchronize();
                RefreshSelectedNodeStyle(treesExplorer.selectedVisualNode());
            } else {
                selectionTitle.refreshPosition(treesExplorer.selectedVisualNode());
            }
            return needSynchronize;
        });

        //#region Initialize

       $surface
            .off('click')
            .on('click', nodeClickHandler);

        $("#commands-panel")
            .off('click')
            .on('click', nodeClickHandler);

        dragDropEvents.onDrop.add(onDropHandler);
        dragDropEvents.onDragOver.add(onDragOverHandler);
        dragDropManager.initSelectionTitleForDrag();

        setNewViewSource(viewSource);

        findInFrame("html").add("html")
            .off('keydown')
            .on('keydown', function(e) {
                if(walker.isDirection(e.which)) {
                    e.preventDefault();
                    e.stopPropagation();
                    changeSelectedNode(e.which);
                }
            });
        //#endregion

        return {
            getViewSource: getViewSource,

            selected: {
                get: function() { return treesExplorer.selectedSourceNode() },
                set: setSelectedSourceNode
            },

            removeNode: removeNode,
            synchronize: synchronize,
            updateSelectedElement: updateSelectedNode,
            deviceOptionsChanged: deviceOptionsChanged,
            setNewViewSource: setNewViewSource,
            setSelectedNode: setSelectedNode,
            onAddCommand: commandsPanel.onAddCommand,
            onEditCommand: commandsPanel.onEditCommand,

            //only for tests
            _tryDrop: tryDrop,
            _getSelectedNodeStyle: GetSelectedNodeStyle,
            _setDragNode: function(node) { dragDropManager._setDragNode(node); },
            _scaleProvider: scaleProvider,
            _changeSelectedNode: changeSelectedNode,
            _viewEngine: function() { return viewRenderer._viewEngineAdapter.viewEngine; }
        };
    };

    function SelectionTitleManager($title, scaleProvider) {
        var selectedNodeMeta;

        function showTitle($sourceNode, $visualNode, meta) {
            if($sourceNode.length !== 1 || $visualNode.length !== 1) {
                $title.hide();
                return;
            }
            selectedNodeMeta = meta;
            var widgetType = meta.getType ? meta.getType() : '';
            $title.text(
                $sourceNode.prop("tagName").toLowerCase() +
                ($sourceNode.attr("id") ? '#' + $sourceNode.attr("id") : '') +
                (
                    widgetType ? '[' + widgetType + ']' :
                    ($sourceNode.attr("class") ? '.' + $sourceNode.attr("class") : '')
                )
            );
            $title.show();
            refreshPosition($visualNode);
        }
        function refreshPosition($visualNode) {
            if($visualNode.length === 1 && selectedNodeMeta) {
                $title.css("cursor", selectedNodeMeta.isDraggable ? "move" : "default");
                if(selectedNodeMeta.isCommand()) {
                    $title.css("position", "fixed");
                    $title.offset({
                        'left': $visualNode.offset().left + 2,
                        'top': $visualNode.offset().top - $title.height() - 2
                    });
                }
                else {
                    $title.css("position", "absolute");
                    var mainWindowPoint = scaleProvider.nodeOffsetInMainWindow($visualNode);
                    $title.offset({
                        'left': mainWindowPoint.left + 2,
                        'top': mainWindowPoint.top - $title.height() - 2
                    });
                }
            }
        }
        function hideTitle() {
            $title.hide();
        }

        return {
            showTitle: showTitle,
            refreshPosition: refreshPosition,
            hideTitle: hideTitle,
            $title: function() { return $title; }
        };
    }
})(DevExpress);