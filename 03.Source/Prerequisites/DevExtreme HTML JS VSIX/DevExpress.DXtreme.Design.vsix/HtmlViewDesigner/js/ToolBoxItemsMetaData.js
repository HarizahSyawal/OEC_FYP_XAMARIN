﻿/// <reference path="jquery.js" />
(function(DX, undefined) {
    var DX_FIELD_CLASS_NAME = 'dx-field',
        DX_FIELDSET_CLASS_NAME = 'dx-fieldset',
        DX_FIELD_KEY_CLASS_NAME = 'dx-field-label',
        DX_FIELD_VALUE_CLASS_NAME = 'dx-field-value',
        widgetsMap = {};

    DX.designer.metadata = {
        byType: getTypeMetadata,
        byNode: getNodeMetadata,
        byHtml: getHtmlMetadata,
        getCommandData: function ($node) {
            var widget = WidgetMetadata.byNode($node);
            return widget
                ? widget.getCommandData($node)
                : undefined;
        },
        setCommandData: function ($node, command) {
            if (!$node.length) {
                return false;
            }

            if (command.data) {
                for (var option in command.data) {
                    if (!command.data[option]) {
                        delete command.data[option];
                    }
                }
            }

            var widget = WidgetMetadata.byNode($node);
            return widget
                ? widget.setCommandData($node, command)
                : null;
        },
        getTypesOfWidgets: function() { return typesOfWidgets;},
        getToolboxItems: function() {
           return $.map(widgetsMap, function(item) {
                return {
                    widgetType: item._type,
                    html: item._defaultHtml
                };
            });
        },
        isContainer : function($node) {
            var md = this.byNode($node);
            return md ? md.isContainer : false;
        },
        getDxTypeByNode: function($node){
            var md = this.byNode($node);
            return (md && md.getType) ? md.getType() : undefined;
        },
        registerWidgets: registerWidgets,
        fieldCommandData: {
            get: function($node) {
                var dxFieldLabel;
                if($node.hasClass(DX_FIELD_KEY_CLASS_NAME)) {
                    dxFieldLabel = $node;
                }
                else if($node.hasClass(DX_FIELD_VALUE_CLASS_NAME)) {
                    dxFieldLabel = $node.siblings('.dx-field-label');
                }
                else {
                    dxFieldLabel = $node.children('.dx-field-label');
                }
                var captionValue = dxFieldLabel ? $.trim(dxFieldLabel.text()) : undefined;
                if(!captionValue) {
                    return undefined;
                }
                return {
                    widgetType: 'dxField',
                    data: JSON.stringify({ caption: captionValue })
                };
            },
            set: function($node, command) {
                if($node.attr('class') === DX_FIELD_CLASS_NAME) {
                    $node.find('.' + DX_FIELD_KEY_CLASS_NAME)
                         .text($.trim(command.data.caption));
                } else if($node.attr('class') === DX_FIELD_KEY_CLASS_NAME) {
                    $node.text($.trim(command.data.caption));
                } else if($node.attr('class') === DX_FIELD_VALUE_CLASS_NAME) {
                    $node.siblings('.' + DX_FIELD_KEY_CLASS_NAME)
                         .text($.trim(command.data.caption));
                }
                return "innerText";
            }
        }
    };

    var _stringify = function (obj, recursively) {
        var t = typeof (obj);
        if(t !== "object" || obj === null) {
            return obj;
        } else {
            var n,
                v,
                json = [],
                arr = (obj && obj.constructor == Array);
            for (n in obj) {
                v = obj[n];
                t = typeof (v);
                if(t !== "function") {
                    if((t !== "string") && (t === "object" && v !== null)) {
                        if(recursively)
                            v = _stringify(v, recursively);
                        else
                            v = JSON.stringify(v);
                    }
                    json.push((arr ? "" : n + ': ') + String((v == null || v == undefined ? '' : v)));
                }
            }
            return (arr ? "[" : "{ ") + json.join(', ') + (arr ? "]" : " }");
        }
    };

    function getHtmlMetadata(html) {
        var res = $.grep(
            $.map(widgetsMap, function (item) {
                return item;
            }),
            function (item) {
                return item._defaultHtml == html;
            }
        );
        if (res.length > 0) {
            return res[0];
        }
    }

    function getTypeMetadata(widgetType) {
        return widgetsMap[widgetType];
    }

    function getNodeMetadata($node) {
        if(!$.isExist($node)) {
            return;
        }

        var widgetMetadata = WidgetMetadata.byNode($node.eq(0));
        if(widgetMetadata) {
            return widgetMetadata;
        }

        var role = $node.attr('data-dx-role');
        if(!!role && dataRoleMap[role]) {
            return dataRoleMap[role];
        }

        var tagMeta = tagMap[$node[0].nodeName.toLowerCase()],
            isDraggable = typeFromData($node, ["dxContent"]) !== "dxcontent",
            isContainer = tagMeta ? tagMeta.isContainer : undefined;
        return new NodeMetadata(isContainer, isDraggable);
    }

    function typeFromData($node, possibleTypes) {
        var bindValue = $node.attr('data-bind') || $node.attr('data-options') || '',
            regexBind = RegExp(possibleTypes.join('|'), 'ig'),
            match = regexBind.exec(bindValue);

        return match && match.length ? match[0].toLowerCase() : null;
    }

    function isValidDxField($node) {
        var $children = $node.children();
        if($children.length === 2) {
            var $label = $children.eq(0),
                $value = $children.eq(1);
            if($label.hasClass(DX_FIELD_KEY_CLASS_NAME) && !$label.hasClass(DX_FIELD_VALUE_CLASS_NAME) &&
                !$value.hasClass(DX_FIELD_KEY_CLASS_NAME) && $value.hasClass(DX_FIELD_VALUE_CLASS_NAME)) {
                return true;
            }
        }
        return false;
    }
    function NodeMetadata(isContainer, isDraggable) {
        this.isContainer = !!isContainer;
        this.isDraggable = !(isDraggable === false);
    }
    NodeMetadata.prototype = {
        getTargetElement: function ($node) {
            var $dxfield = $node.closest('.' + DX_FIELD_CLASS_NAME);
            if(isValidDxField($dxfield)) {
                return $dxfield.find('.' + DX_FIELD_VALUE_CLASS_NAME);
            }

            var list = $node.closest('[data-bind^=dxList]');
            if (list.length) {
                return list.parent();
            }

            var $cursor = $node;
            do {
                var meta = getNodeMetadata($cursor);
                if (meta && meta.isContainer ) {
                    return $cursor;
                }
                $cursor = $cursor.parent();
            } while($cursor.length);
            return null;
        },
        isCommand: function() {
            return false;
        }
    };
    WidgetMetadata.byNode = function($node) {
        var widgetType = typeFromData($node, typesOfWidgets);
        if(widgetType) {
            return widgetsMap[widgetType];
        }

        if($node.hasClass(DX_FIELDSET_CLASS_NAME)) {
            return widgetsMap["dxfieldset"];
        }
        
        var $dxField = $node.hasClass(DX_FIELD_CLASS_NAME) ? $node : $node.parent();
        if($dxField.hasClass(DX_FIELD_CLASS_NAME) && isValidDxField($dxField)) {
            return widgetsMap["dxfield"];
        }
    };
    //type, html, { isContainer, getTargetElement, getCommandData }
    function WidgetMetadata(type, html, xtra) {
        if(!type) { throw Error('type argument is required.'); }
        //if(!html) { throw Error('html argument is required.'); }

        //base ctor call
        NodeMetadata.apply(this, xtra ? [xtra.isContainer, xtra.isDraggable] : []);

        this._base = {};
        this._type = type;
        this._defaultHtml = html;
        var propertiesAttr = xtra && xtra.propertiesAttr;
        if(Object.prototype.toString.call(propertiesAttr) === '[object Array]') {
            this._propertiesAttr = propertiesAttr;
        }
        else {
            this._propertiesAttr = propertiesAttr ? [].concat(propertiesAttr) : [].concat('data-bind', 'data-options');
        }

        for(var key in xtra) if(xtra.hasOwnProperty(key)) {
            if(this[key]) {
                this._base[key] = this[key];
            }
            this[key] = xtra[key];
        }
    }
    WidgetMetadata.prototype = $.extend({
        getType: function() {
            return this._type;
        },
        getHtml: function(wrap) {
            return wrap
                ? $(this._defaultHtml)
                : this._defaultHtml;
        },
        getCommandData: function ($node) {
            var propertiesAttr = this._propertiesAttr;
            var parser = new DevExpress.designer.BindingParser(typesOfWidgets);
            var commandData;
            var self = this;

            for(var i = 0; i < propertiesAttr.length; i++) {
                commandData = parser.parse($node, propertiesAttr[i]);
                if(commandData) {
                    break;
                }
            }

            var data = JSON.parse(commandData.data);
            if(!data.items) {
                var dataItems = [];
                jQuery.each($node.children(), function (index, child) {
                    for(var i = 0; i < propertiesAttr.length; i++) {
                        var item = parser.parse(child, propertiesAttr[i]);
                        if(item && item.widgetType == "dxItem") {
                            var data = JSON.parse(item.data);
                            data.html = self.normalizeHtml(child.innerHTML);
                            dataItems.push(data);
                        }
                    }
                });
                if(dataItems.length > 0)
                    data.items = _stringify(dataItems, true).replace(/\"|/g, "");
                commandData.data = JSON.stringify(data);
            }
            return commandData;
        },
        setCommandData: function ($node, command) {
            var parser = new DevExpress.designer.BindingParser(typesOfWidgets),
                    widgetProps,
                    attr;

            for(var i = 0; i < this._propertiesAttr.length; i++) {
                widgetProps = parser.parse($node, this._propertiesAttr[i]);
                if(widgetProps) {
                    attr = this._propertiesAttr[i];
                    break;
                }
            }

            if(widgetProps) {
                var haveDxItems = $node.contents().filter(function () {
                                        return $(this).attr('data-options') ? $(this).attr('data-options').indexOf('dxItem:') > -1 : false;
                                    }).length > 0;
                var itemsAsContent = !JSON.parse(widgetProps.data).items && haveDxItems;
                var dxItems;
                var self = this;

                if(itemsAsContent) {
                    dxItems = command.data.items;
                    delete command.data.items;
                }

                var dataBind = parser.stringify(command.widgetType, command.data);
                if(command.additionalWidgetType && command.additionalData) {
                    dataBind += ', ' + parser.stringify(command.additionalWidgetType, command.additionalData);
                }
                if(widgetProps.otherBindings) {
                    dataBind += ', '.concat($.trim(widgetProps.otherBindings));
                }
                $node.attr(attr, dataBind);

                if(itemsAsContent) {
                    $node.contents().filter(function () {
                        var isTextNode = this.nodeType == 3;
                        var isDxItem = $(this).attr('data-options')
                                            ? $(this).attr('data-options').indexOf('dxItem:') > -1
                                            : false;
                        return isTextNode || isDxItem;
                    }).remove();

                    if(dxItems) {
                        jQuery.each(DevExpress.designer.json_parse(dxItems, function (k, v) { return v; }), function (index, item) {
                            var html = self.normalizeHtml(item.html);
                            delete item.html;

                            var dxItem = $("<div data-options=\"dxItem: " + _stringify(item, true) + " \">" + html + "</div>");
                            $node.append(dxItem);
                        });
                    }

                    return {
                        updatedAttr: attr,
                        updatedContent: $node.html() ? $node.html() : "\n"
                    };
                }
                return attr;
            }
            return null;
        },
        stringify: function(data) {
            return this._type + ': ' + _stringify(data);
        },
        isCommand: function() {
            return this._type === 'dxCommand';
        },
        isAvailableJoinData: function ($target) {
            if(this.isJoinable) {
                return typeFromData($target, this.joinableWidgets) != null
                    && typeFromData($target, [this._type.toString()]) == null;
            }
            return false;
        },
        normalizeHtml: function (html) {
            html = html.replace(/^'*((.|\n)*?)'*$/g, '$1')
                .replace(/\\{1,}n/g, "\n")
                .replace(/\\{1,}'/g, "\'")
                .replace(/\"/g, "\'");

            var match = html.match(/[^\s]*[.*]*(?:(?=\n+)\s*<\/[a-zA-Z]+>).*/g);
            if(match) {
                for(var i = 0; i < match.length; i++) {
                    html = html.replace(match[i], match[i].replace(/\n|\s/g, ''));
                }
            }
            return $.trim(html);
        }
    }, NodeMetadata.prototype);

    var tagMap = {
        p: {isContainer: false},
        ul: { isContainer: false },
        li: { isContainer: true },
        div: { isContainer: true },
        button: { isContainer: false }
    };

    var dataRoleMap = {
        'view': new NodeMetadata(true, false),
        'placeholder': new NodeMetadata(true, false)
    };

    var typesOfWidgets = [];
    function registerWidget(name, html, xtra, propertiesAttr) {
        var key;
        if (!name) {
            throw Error('Widget name is required.');
        }
        key = name.toLowerCase();
        widgetsMap[key] = new WidgetMetadata(name, html, xtra, propertiesAttr);
        if($.inArray(widgetsMap[key].getType()) === -1) {
            typesOfWidgets.push(widgetsMap[key].getType());
        }
    }
    function registerWidgets(widgets) {
        for(var name in widgets) {
            if((typeof widgets[name]) === "string") {
                registerWidget(name, widgets[name]);
            } else {
                registerWidget(name, widgets[name].html, widgets[name].options);
            }
        }
    }

})(DevExpress);