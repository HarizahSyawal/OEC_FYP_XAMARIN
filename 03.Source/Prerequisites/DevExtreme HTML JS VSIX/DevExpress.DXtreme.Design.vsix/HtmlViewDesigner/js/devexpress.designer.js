﻿(function($, global, undefined) {
    global.DevExpress = global.DevExpress || {};
    DevExpress.designer = {
        commands: {},
        "13.1": {},
        "13.2": {},
        "14.1": {},
        "14.2": {},
        "15.1": {},
        "15.2": {},
        "17.1": {},
        "17.2": {},
        "18.1": {},
        "18.2": {},
        rootElement: "body"
    };
    // $(":dxElement(dxView)")
    $.expr[':'].dxElement = function(obj, index, meta, stack) {
        var $el = $(obj),
        componentName = meta[3],
        pattern = ".*" + componentName + "('|\")?\\s*:\\s*{";
        return RegExp(pattern).test($el.attr('data-options'));
    };

    $.extend({
        isExist: function(o) {
            return !!(o && o.length);
        },
        containsOrSame: function(container, content) {
            if(container && content) {
                return container === content || $.contains(container, content);
            }
            return false;
        },
        originalEvent: function(event) {
            return event.originalEvent || event;
        }
    });
    $.fn.findWithRoot = function(selector) {
        return this.filter(selector).add(this.find(selector));
    };
    
    function _patchKoFunctions(koToPatch, bindingParser) {
        var oldApplyBindings = koToPatch.applyBindings,
           newApplyBindings = function(viewModelOrBindingContext, rootNode) {
               try {
                   return oldApplyBindings(viewModelOrBindingContext, rootNode);
               } catch(ex) {
                   $(rootNode).html(
                       $("<div class='missing-template'>" + ex.message + "</div>").attr("title", ex.message)
                   );
               }
           };
        DevExpress.designer.utils.redefinePopertyValue(koToPatch, oldApplyBindings, newApplyBindings);

        var oldMakeTemplateSource = koToPatch.templateEngine.prototype.makeTemplateSource,
            newMakeTemplateSource = function(template, templateDocument) {
                if(typeof template == "string") {
                    var element = templateDocument.getElementById(template);
                    if(!element) {
                        var message = "Cannot find template with ID '" + template + "'",
                            $messageDiv = $("<div class='missing-template'>" + message + "</div>").attr("title", message);
                        $(templateDocument.body).append($("<div id='" + template + "' />").html($messageDiv));
                    } else {
                        //B252609
                        bindingParser.patch(element, {});
                    }
                }
                return oldMakeTemplateSource(template, templateDocument);
            }
        DevExpress.designer.utils.redefinePopertyValue(koToPatch.templateEngine.prototype, oldMakeTemplateSource, newMakeTemplateSource);
    }

    function _setViewContent(pageContent, config, deviceOptions) {
        var bindingParser = new DevExpress.designer.BindingParser(DevExpress.designer.metadata.getTypesOfWidgets(), urlsPatcher);
        _patchKoFunctions(DevExpress.designer.frameWindow.ko, bindingParser);
        $.ajax = function(args) {
            var deferred = $.Deferred();
            return deferred.promise();
        };

        _createViewEngineAdapter(config, deviceOptions, bindingParser, urlsPatcher, function(viewEngineAdapter) {
            viewDesigner = DevExpress.designer.createViewDesigner(pageContent, viewEngineAdapter, bindingParser, urlsPatcher, frameworkAdapter.isCommandMappingEnabled());
            if(frameworkAdapter.isCommandMappingEnabled()) {
                var commandsMapper = DevExpress.designer.commands.Mapper(config, frameworkAdapter);
                viewDesigner.onAddCommand.add(commandsMapper.addNewCommand);
                viewDesigner.onEditCommand.add(commandsMapper.editCommand);
            }
        });
    }

    function _createViewEngineAdapter(config, deviceOptions, bindingParser, urlsPatcher, callback) {
        frameworkAdapter = new DevExpress.designer.frameworkAdapter({
            frameDX: DevExpress.designer.frameWindow.DevExpress,
            config: config,
            $root: DevExpress.designer.frameWindow.$(DevExpress.designer.rootElement),
            $viewPort: DevExpress.designer.frameWindow.$("#visualTree-content"),
            bindingParser: bindingParser,
            urlsPatcher: urlsPatcher
        });
        frameworkAdapter.loadToolboxItems();
        frameworkAdapter.loadAvailablePlatforms(deviceOptions);
        DevExpress.designer.setSimulatorOptions(deviceOptions);
        frameworkAdapter.setDevice(deviceOptions);
        frameworkAdapter.createViewEngineAdapter(callback);
    }

    var urlsPatcher, frameworkAdapter;
    $(function() {
        urlsPatcher = DevExpress.designer.createUrlsPatcher();
    });
    $.extend(DevExpress.designer, {
        SetViewContent: function(pageContent, headContent, deviceOptions) {
            urlsPatcher.addLinksToHeader(headContent);
            if (DevExpress.designer.frameWindow.DevExpress == undefined)
                throw {
                    internal: true,
                    message: "View Designer can be used in <a href='http://js.devexpress.com/Documentation/Guide/Common/Introduction_to_DevExtreme/#Mobile_Development'>DevExtreme SPA Framework</a>-based applications only. In angular-based applications, implement views in HTML files. So, rename your .dxView file to .html."
                }
            DevExpress.designer.frameWindow.$(wrapWithTryCatch(function() {
                var config = DevExpress.designer.getAppConfig(headContent);
                _setViewContent(pageContent, config, deviceOptions);
            }));
        },
        SetDeviceOptions: function(deviceOptions) {
            var needUpdateViewEngine = frameworkAdapter.setDevice(deviceOptions);
            if(needUpdateViewEngine) {
                frameworkAdapter.createViewEngineAdapter(function(viewEngineAdapter) {
                    viewDesigner.deviceOptionsChanged(needUpdateViewEngine, viewEngineAdapter);
                });
            } else {
                viewDesigner.deviceOptionsChanged(needUpdateViewEngine);
            }
            return needUpdateViewEngine;
        },
        getPlatforms: function() {
            return frameworkAdapter.getPlatforms();
        },
        createViewEngine: function(device, $root) {
            return frameworkAdapter.createViewEngine(device, $root);
        },
        setSimulatorOptions: function(options) {
            if(this.simulator) {
                this.simulator.options({
                    "device": options.device,
                    "orientation": options.orientation,
                    "chrome": (options.chrome ? "simple" : "none"),
                    "scale": options.scaleFactor,
                    "genericTheme": options.device === "generic"
                });
            }
        },

        //only for tests
        _setViewContent: _setViewContent,
        _createViewEngineAdapter: _createViewEngineAdapter,
        _setDevice: function(deviceOptions) {
            frameworkAdapter.setDevice(deviceOptions);
        }
    });

})(jQuery, this);