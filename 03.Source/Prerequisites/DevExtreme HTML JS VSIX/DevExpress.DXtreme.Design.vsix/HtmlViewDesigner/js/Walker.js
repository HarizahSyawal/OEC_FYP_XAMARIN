﻿(function(DX) {
    DX.designer.createWalker = Walker;

    Walker.directions = {
        up: 38,
        down: 40,
        toParent: 27
    };

    function Walker($root) {
        var skipSelectorsString;
        var $rootLastChild = $root.children().last();

        var selectorsToSkip = ['[data-dx-role=template],:dxElement(dxTemplate)'];

        function go($from, direction) {
            var $ret = $from;

            $rootLastChild = $root.children().last();
            recompileNotSelectorsString();

            //↑
            if(direction === Walker.directions.up) {
                $ret = goUp($from);
            }

            //↓
            if(direction === Walker.directions.down) {
                $ret = goDown($from);
            }

            //Escape
            if(direction === Walker.directions.toParent) {
                $ret = goToParent($from);
            }
            return $ret;
        }

        function goUp($from) {
            if(!$from || !$from.length || $from.is($root)) {
                return $from;
            }

            if($from.prev().children().length) {
                return $from.prev().children().last();
            }

            if($from.prev().length) {
                return $from.prev();
            }

            return $from.parent();
        }

        function goDown($from) {
            var $initial = $from;
            if(!$from || !$from.length) {
                return $from;
            }
            if($from.children().not(skipSelectorsString).length) {
                return $from.children().not(skipSelectorsString).first();
            }

            if($from.next().length) {
                return $from.next();
            }

            if($from.parent().next().length) {
                return $from.parent().next();
            }

            do {
                if($from.is($rootLastChild)) {
                    return $initial;
                }

                if($from.parent().is($root)) {
                    return $from;
                }
                if($from.parent().next().length) {
                    return $from.parent().next();
                }

                $from = $from.parent();
            } while($from.length);

            return $from;
        }

        function goToParent($from) {
            if(!$from || !$from.length || $from.is($root)) {
                return $from;
            }
            return $from.parent();
        }

        function recompileNotSelectorsString() {
            skipSelectorsString = selectorsToSkip.length
                ? selectorsToSkip.join(',')
                : '';
        }

        return {
            go: go,
            up: function($from) {
                return go($from, Walker.directions.up);
            },
            down: function($from) {
                return go($from, Walker.directions.down);
            },
            toParent: function($from) {
                return go($from, Walker.directions.toParent);
            },

            skipSelectors: {
                get: function() {
                    return selectorsToSkip;
                },
                has: function(selector) {
                    return selectorsToSkip.indexOf(selector) > -1;
                },
                add: function(selector) {
                    if(!this.has(selector)) {
                        selectorsToSkip.push(selector);
                        return true;
                    }
                    return false;
                },
                remove: function(selector) {
                    if(has(selector)) {
                        selectorsToSkip.slice(selector.indexOf(selector), 1);
                        return true;
                    }
                    return false;
                }
            },

            isDirection: function(which) {
                return which === Walker.directions.up || which === Walker.directions.down || which === Walker.directions.toParent;
            }
        };
    }
})(DevExpress);