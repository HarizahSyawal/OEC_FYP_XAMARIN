﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["13.2"].viewEngineAdapter = viewEngineAdapter;

    function viewEngineAdapter(viewEngine, layoutControllers, layoutName, frameDX) {
        this._init(viewEngine, layoutControllers, layoutName, frameDX);
    };

    $.extend(viewEngineAdapter.prototype, {
        _init: function(viewEngine, layoutControllers, layoutName, frameDX) {
            this.viewEngine = viewEngine;
            this._DX = frameDX;
            this._currentLayoutController = this._currentLayoutController(layoutControllers, layoutName);
            if(!this._currentLayoutController) {
                throw Error("The layout controller cannot be resolved. There are no appropriate layout controllers for the current context.");
            }
        },
        _currentLayoutController: function(layoutControllers, layoutName) {
            var controller = null;
            $.each(layoutControllers, function(index, controllerInfo) {
                var name = (controllerInfo.navigationType || "default") + (controllerInfo.root ? " (inner)" : "");
                if(name === layoutName) {
                    controller = controllerInfo.controller;
                    return false;
                }
            });
            return controller;
        },
        clearSurface: function($surface) {
            var $frameSurface = DX.designer.frameWindow.$($surface[0]); //TODO: check if need for all $visualTree references
            $frameSurface.find(".dx-active-view").empty();
            $frameSurface.children().detach();
        },
        appendViewToSurface: function($surface, $renderedView) {
            if($surface.children().length !== 1) {
                $surface.children().remove();
                $surface.append($renderedView);
            }
        },
        getRenderedMarkup: function($view, model, $surface) {
            this.viewEngine._createComponents($view);
            this.viewEngine._extendModelFormViewTemplate($view, model);
            var viewInfo = {
                model: model,
                $viewTemplate: $view,
                routeData: {},
                commands: []
            };
            this._currentLayoutController.activate();
            this._currentLayoutController.showView(viewInfo)
            return viewInfo.renderResult.$markup;
        }
    });

})(DevExpress);