﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["14.2"].viewEngineAdapter = viewEngineAdapter;

    function viewEngineAdapter(viewEngine, layoutControllers, layoutName, frameDX) {
        this._init(viewEngine, layoutControllers, layoutName, frameDX);
    };
    $.extend(viewEngineAdapter.prototype, DX.designer["14.1"].viewEngineAdapter.prototype, {
        _createComponents: function($elements) {
            this._DX.utils.createComponents($elements);
        },
        _getViewTemplateInfo: function(viewName) {
            var viewComponent = this.viewEngine.getViewTemplateInfo(viewName);
            return viewComponent && viewComponent.option();
        },
        clearSurface: function($surface) {
            var $frameSurface = DX.designer.frameWindow.$($surface[0]); //TODO: check if need for all $visualTree references
            $frameSurface.find(".dx-active-view").empty();
        },
        appendViewToSurface: function($surface, $renderedView) {
        },
        getRenderedMarkup: function($view, model, $surface) {
            this._renderView($view, model);
            return this._currentLayoutController._$mainLayout;
        }
    });

})(DevExpress);