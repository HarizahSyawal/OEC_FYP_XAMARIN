﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["14.1"].viewEngineAdapter = viewEngineAdapter;

    function viewEngineAdapter(viewEngine, layoutControllers, layoutName, frameDX) {
        this._init(viewEngine, layoutControllers, layoutName, frameDX);
    };
    $.extend(viewEngineAdapter.prototype, DX.designer["13.2"].viewEngineAdapter.prototype, {
        _currentLayoutController: function(layoutControllers, layoutName) {
            return layoutControllers[0] && layoutControllers[0].controller;
        },
        _getViewTemplateInfo: function(viewName) {
            var viewComponent = this.viewEngine.findViewComponent(viewName);
            return viewComponent && viewComponent.option();
        },
        _createComponents: function($elements) {
            this.viewEngine._createComponents($elements);
        },
        _renderView: function($view, model) {
            this._createComponents($view);
            this.viewEngine._extendModelFormViewTemplate($view, model);
            var viewInfo = {
                model: model,
                $viewTemplate: $view,
                routeData: {},
                commands: [],
                viewTemplateInfo: this._getViewTemplateInfo(model.name) || {}
            };
            this._currentLayoutController.activate();
            this._currentLayoutController.showView(viewInfo)
            return viewInfo;
        },
        getRenderedMarkup: function($view, model) {
            var viewInfo = this._renderView($view, model);
            return viewInfo.renderResult.$markup;
        }
    });

})(DevExpress);