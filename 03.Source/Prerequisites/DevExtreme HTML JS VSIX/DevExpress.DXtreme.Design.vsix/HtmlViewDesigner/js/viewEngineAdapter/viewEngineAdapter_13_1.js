﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-latest.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {

    DX.designer["13.1"].viewEngineAdapter = viewEngineAdapter;

    function viewEngineAdapter(viewEngine, layoutControllers) {
        this.viewEngine = viewEngine;
        this._layoutControllers = layoutControllers;
    }
    $.extend(viewEngineAdapter.prototype, {
        clearSurface: function($surface) {
            $surface.children().remove();
        },
        appendViewToSurface: function($surface, $renderedView) {
            if($surface.children().length !== 1 || $surface.children().get(0) !== $renderedView.get(0)) {
                $surface.children().remove();
                $surface.append($renderedView);
            }
        },
        getRenderedMarkup: function($view, model, $surface) {
            if(this.viewEngine._createComponents) {
                this.viewEngine._createComponents($view); //TODO: devextreme framework version?
            }
            this.viewEngine._extendModelFormViewTemplate($view, model);
            var viewInfo = {
                model: model,
                $viewTemplate: $view,
                routeData: {},
                commands: []
            };
            this.viewEngine.renderBlankView(viewInfo, $surface);
            this._showView(viewInfo);
            this.viewEngine.renderCompleteView(viewInfo, $surface);
            return viewInfo.renderResult.$markup;
        },
        _showView: function(viewInfo) {
            var layoutControllerName = 'empty';
            if(viewInfo.renderResult) {
                layoutControllerName = viewInfo.renderResult.layoutControllerName || 'empty';
            }
            if(this._layoutControllers && this._layoutControllers[layoutControllerName]) {
                var controller = this._layoutControllers[layoutControllerName];
                controller.activate();
                controller.showView(viewInfo);
            }
        }
    });

})(DevExpress);