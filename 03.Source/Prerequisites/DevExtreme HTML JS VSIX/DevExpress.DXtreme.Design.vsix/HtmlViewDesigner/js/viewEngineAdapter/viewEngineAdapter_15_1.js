﻿/// <reference path="../scripts/jquery.js" />
/// <reference path="../scripts/knockout-3.2.0.debug.js" />
/// <reference path="mergely.js" />
(function(DX) {


    DX.designer["15.1"].viewEngineAdapter = viewEngineAdapter;

    function viewEngineAdapter(viewEngine, layoutControllers, layoutName, frameDX) {
        this._init(viewEngine, layoutControllers, layoutName, frameDX);
    };
	
    $.extend(viewEngineAdapter.prototype, DX.designer["14.2"].viewEngineAdapter.prototype, {
		
	});	

})(DevExpress);